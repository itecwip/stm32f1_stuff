/**
 * @file libmaple/systick.c
 * @brief System timer (SysTick).
 */

#include <systick.h>

volatile uint32_t systick_uptime_millis;

//static void (*systick_user_callback)(void);

/**
 * @brief Attach a callback to be called from the SysTick exception handler.
 *
 * To detach a callback, call this function again with a null argument.
 */
//void systick_attach_callback(void (*callback)(void)) {
//    systick_user_callback = callback;
//}

/*
 * SysTick ISR
 */
//void __exc_systick(void) {
void SysTick_Handler(void) __attribute__ ((isr));
void SysTick_Handler(void) {
    systick_uptime_millis++;
//    if (systick_user_callback) {
//       systick_user_callback();
//    }
}
