#ifndef __NR_LIB_H
#define __NR_LIB_H

#include "stm32f10x.h"
#include <nr_stddef.h>

/**
  memory mapped structure for System Control Block (SCB)
 */
typedef struct
{
	volatile const  uint32_t CPUID;                 /*!< Offset: 0x00  CPU ID Base Register                                  */
	volatile uint32_t ICSR;                         /*!< Offset: 0x04  Interrupt Control State Register                      */
	volatile uint32_t VTOR;                         /*!< Offset: 0x08  Vector Table Offset Register                          */
	volatile uint32_t AIRCR;                        /*!< Offset: 0x0C  Application Interrupt / Reset Control Register        */
	volatile uint32_t SCR;                          /*!< Offset: 0x10  System Control Register                               */
	volatile uint32_t CCR;                          /*!< Offset: 0x14  Configuration Control Register                        */
	volatile uint8_t  SHP[12];                      /*!< Offset: 0x18  System Handlers Priority Registers (4-7, 8-11, 12-15) */
	volatile uint32_t SHCSR;                        /*!< Offset: 0x24  System Handler Control and State Register             */
	volatile uint32_t CFSR;                         /*!< Offset: 0x28  Configurable Fault Status Register                    */
	volatile uint32_t HFSR;                         /*!< Offset: 0x2C  Hard Fault Status Register                            */
	volatile uint32_t DFSR;                         /*!< Offset: 0x30  Debug Fault Status Register                           */
	volatile uint32_t MMFAR;                        /*!< Offset: 0x34  Mem Manage Address Register                           */
	volatile uint32_t BFAR;                         /*!< Offset: 0x38  Bus Fault Address Register                            */
	volatile uint32_t AFSR;                         /*!< Offset: 0x3C  Auxiliary Fault Status Register                       */
	volatile const  uint32_t PFR[2];                /*!< Offset: 0x40  Processor Feature Register                            */
	volatile const  uint32_t DFR;                   /*!< Offset: 0x48  Debug Feature Register                                */
	volatile const  uint32_t ADR;                   /*!< Offset: 0x4C  Auxiliary Feature Register                            */
	volatile const  uint32_t MMFR[4];               /*!< Offset: 0x50  Memory Model Feature Register                         */
	volatile const  uint32_t ISAR[5];               /*!< Offset: 0x60  ISA Feature Register                                  */
} SCB_Type;

/*
  memory mapped structure for SysTick
 */
typedef struct
{
	volatile uint32_t CTRL;                         /*!< Offset: 0x00  SysTick Control and Status Register */
	volatile uint32_t LOAD;                         /*!< Offset: 0x04  SysTick Reload Value Register       */
	volatile uint32_t VAL;                          /*!< Offset: 0x08  SysTick Current Value Register      */
	volatile const  uint32_t CALIB;                        /*!< Offset: 0x0C  SysTick Calibration Register        */
} SysTick_Type;

/* Memory mapping of Cortex-M3 Hardware */
#define SCS_BASE            (0xE000E000)                              /*!< System Control Space Base Address */
#define ITM_BASE            (0xE0000000)                              /*!< ITM Base Address                  */
#define CoreDebug_BASE      (0xE000EDF0)                              /*!< Core Debug Base Address           */
#define SysTick_BASE        (SCS_BASE +  0x0010)                      /*!< SysTick Base Address              */
//#define NVIC_BASE           (SCS_BASE +  0x0100)                      /*!< NVIC Base Address                 */
#define SCB_BASE            (SCS_BASE +  0x0D00)                      /*!< System Control Block Base Address */

#define InterruptType       ((InterruptType_Type *) SCS_BASE)         /*!< Interrupt Type Register           */
#define SCB                 ((SCB_Type *)           SCB_BASE)         /*!< SCB configuration struct          */
#define SysTick             ((SysTick_Type *)       SysTick_BASE)     /*!< SysTick configuration struct      */
#define NVIC                ((NVIC_Type *)          NVIC_BASE)        /*!< NVIC configuration struct         */
#define ITM                 ((ITM_Type *)           ITM_BASE)         /*!< ITM configuration struct          */
#define CoreDebug           ((CoreDebug_Type *)     CoreDebug_BASE)   /*!< Core Debug configuration struct   */

// sys.h
#define BITBAND(addr, bitnum)	((addr & 0xF0000000) + 0x2000000 + ((addr & 0xFFFFF)<< 5) + (bitnum << 2))
#define MEM_ADDR(addr)  		*((volatile unsigned long *)(addr))
#define BIT_ADDR(addr, bitnum)	MEM_ADDR(BITBAND(addr, bitnum))

#define GPIOA_ODR_Addr    (GPIOA_BASE+12) //0x4001080C
#define GPIOB_ODR_Addr    (GPIOB_BASE+12) //0x40010C0C
#define GPIOC_ODR_Addr    (GPIOC_BASE+12) //0x4001100C
#define GPIOD_ODR_Addr    (GPIOD_BASE+12) //0x4001140C
#define GPIOE_ODR_Addr    (GPIOE_BASE+12) //0x4001180C
#define GPIOF_ODR_Addr    (GPIOF_BASE+12) //0x40011A0C
#define GPIOG_ODR_Addr    (GPIOG_BASE+12) //0x40011E0C

#define GPIOA_IDR_Addr    (GPIOA_BASE+8) //0x40010808
#define GPIOB_IDR_Addr    (GPIOB_BASE+8) //0x40010C08
#define GPIOC_IDR_Addr    (GPIOC_BASE+8) //0x40011008
#define GPIOD_IDR_Addr    (GPIOD_BASE+8) //0x40011408
#define GPIOE_IDR_Addr    (GPIOE_BASE+8) //0x40011808
#define GPIOF_IDR_Addr    (GPIOF_BASE+8) //0x40011A08
#define GPIOG_IDR_Addr    (GPIOG_BASE+8) //0x40011E08


#define PAout(n)   BIT_ADDR(GPIOA_ODR_Addr,n)  //���
#define PAin(n)    BIT_ADDR(GPIOA_IDR_Addr,n)  //����

#define PBout(n)   BIT_ADDR(GPIOB_ODR_Addr,n)  //���
#define PBin(n)    BIT_ADDR(GPIOB_IDR_Addr,n)  //����

#define PCout(n)   BIT_ADDR(GPIOC_ODR_Addr,n)  //���
#define PCin(n)    BIT_ADDR(GPIOC_IDR_Addr,n)  //����

#define PDout(n)   BIT_ADDR(GPIOD_ODR_Addr,n)  //���
#define PDin(n)    BIT_ADDR(GPIOD_IDR_Addr,n)  //����

#define PEout(n)   BIT_ADDR(GPIOE_ODR_Addr,n)  //���
#define PEin(n)    BIT_ADDR(GPIOE_IDR_Addr,n)  //����

#define PFout(n)   BIT_ADDR(GPIOF_ODR_Addr,n)  //���
#define PFin(n)    BIT_ADDR(GPIOF_IDR_Addr,n)  //����

#define PGout(n)   BIT_ADDR(GPIOG_ODR_Addr,n)  //���
#define PGin(n)    BIT_ADDR(GPIOG_IDR_Addr,n)  //����

/**
 * @brief Delay the given number of microseconds.
 *
 * @param us Number of microseconds to delay.
 */
static inline void delay_us(uint32_t us) {
    us *= STM32_DELAY_US_MULT;

    /* fudge for function call overhead  */
    us--;
    asm volatile("   mov r0, %[us]          \n\t"
                 "1: subs r0, #1            \n\t"
                 "   bhi 1b                 \n\t"
                 :
                 : [us] "r" (us)
                 : "r0");
}

/**
 * Delay for at least the given number of milliseconds.
 *
 * Interrupts, etc. may cause the actual number of milliseconds to
 * exceed ms.  However, this function will return no less than ms
 * milliseconds from the time it is called.
 *
 * @param ms the number of milliseconds to delay.
 * @see delayMicroseconds()
 */
void delay_ms(uint32_t ms);


void SystemInit(void);

#endif





























