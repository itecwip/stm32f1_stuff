gpio usage via stm32f10x.h:
===========================

// Configuration for port 0 to 7
GPIO_CRL_MODE[0-7]		= MODE[11]	->  ~(GPIO_CRL_MODE[0-7]) = MODE[00]
GPIO_CRL_MODE[0-7]_0	= MODE[01]
GPIO_CRL_MODE[0-7]_1	= MODE[10]

GPIO_CRL_CNF[0-7]		= CNF[11]	->  ~(GPIO_CRL_CNF[0-7]) = CNF[00]
GPIO_CRL_CNF[0-7]_0		= CNF[01]
GPIO_CRL_CNF[0-7]_1		= CNF[10]

// Configuration for port 8 to 15
GPIO_CRH_MODE[8-15]		= MODE[11]	->  ~(GPIO_CRH_MODE[0-7]) = MODE[00]
GPIO_CRH_MODE[8-15]_0	= MODE[01]
GPIO_CRH_MODE[8-15]_1	= MODE[10]

GPIO_CRH_CNF[8-15]		= CNF[11]	->  ~(GPIO_CRH_CNF[0-7]) = CNF[00]
GPIO_CRH_CNF[8-15]_0	= CNF[01]
GPIO_CRH_CNF[8-15]_1	= CNF[10]

if (MODE[00]) {
	Input mode (reset state) 
	CNF[00]  Analog mode
	CNF[01]  Floating input (reset state)
	CNF[10]  Input with pull-up / pull-down
	CNF[11]  Reserved (not used)
} else {
	MODE[01] Output mode, max speed 10 MHz.
	MODE[10] Output mode, max speed 2 MHz.
	MODE[11] Output mode, max speed 50 MHz.
	CNF[00]  General purpose output push-pull
	CNF[01]  General purpose output Open-drain
	CNF[10]  Alternate function output Push-pull
	CNF[11]  Reserved (not used)
}

Example:
// Setup PC13 (led) in output push-pull at 50 MHz
// clear the MODE and CNF fields of port 13 (CNF13[00]- MODE13[00] : Input mode, Analog Mode)
GPIOC->CRH &= ~(GPIO_CRH_MODE13 | GPIO_CRH_CNF13);
// Output push-pull, Output mode, max speed 50 MHz. (CNF13[00] - MODE13[11])
GPIOC->CRH |= GPIO_CRH_MODE13;

// Bit set on PC13
#define LED_ON		(GPIOC->BSRR = GPIO_BSRR_BS13)
// Bit reset on PC13
#define LED_OFF		(GPIOC->BSRR = GPIO_BSRR_BR13)


// Port PC13 input pull-up (button)
// clear the MODE and CNF fields of port 13 (CNF13[00]- MODE13[00] : Input mode, Analog Mode)
GPIOC->CRH &= ~(GPIO_CRH_CNF13 | GPIO_CRH_MODE13);
// Input with pull-up / pull-down (CNF13[10])
GPIOC->CRH |= GPIO_CRH_CNF13_1;
GPIOC->BSRR = GPIO_BSRR_BS13; // set input in pull-up mode 
or
GPIOC->BSRR = GPIO_BSRR_BR13; // set input in pull-down mode 


=====================================
Setup SysTick Timer for 1 msec interrupts.
------------------------------------------
    1. The SysTick_Config() function is a CMSIS function which configure:
       - The SysTick Reload register with value passed as function parameter.
       - Configure the SysTick IRQ priority to the lowest value (0x0F).
       - Reset the SysTick Counter register.
       - Configure the SysTick Counter clock source to be Core Clock Source (HCLK).
       - Enable the SysTick Interrupt.
       - Start the SysTick Counter.
    
    2. You can change the SysTick Clock source to be HCLK_Div8 by calling the
       SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8) just after the
       SysTick_Config() function call. The SysTick_CLKSourceConfig() is defined
       inside the misc.c file.

    3. You can change the SysTick IRQ priority by calling the
       NVIC_SetPriority(SysTick_IRQn,...) just after the SysTick_Config() function 
       call. The NVIC_SetPriority() is defined inside the core_cm3.h file.

    4. To adjust the SysTick time base, use the following formula:
                            
         Reload Value = SysTick Counter Clock (Hz) x  Desired Time base (s)
    
       - Reload Value is the parameter to be passed for SysTick_Config() function
       - Reload Value should not exceed 0xFFFFFF


=====================================

CMSIS Cortex-M3 migration

Files from STM32F10x Standard Peripherals Library V3.5.0 / 08-April-2011:
- STM32F10x_StdPeriph_Lib/Libraries/CMSIS/CM3/DeviceSupport/ST/STM32F10x/stm32f10x.h (V3.5.0 11-March-2011)
- STM32F10x_StdPeriph_Lib/Libraries/CMSIS/CM3/CoreSupport/core_cm3.h ( V1.30 30. October 2009)

Copy stm32f10x.h and core_cm3.h into ./lib/includes
in stm32f10x.h:
uncomment line 68 : #define STM32F10X_MD
comment line 479  : // #include "system_stm32f10x.h"

Remove the files ./lib/includes/scb.h and nr_stddef.h

Remove duplicate definitions:
nr_lib.h  core_cm3 definitions (SCB_Type, SysTick_Type, ...) sys.h def.
nvic.h (nvic_reg_map, NVIC_BASE)
nr_stddef.h (nvic_irq_num)

Modifications:
systick.h:
	comment #include <nr_stddef.h> and all functions except systick_uptime() and systick_get_count()
	replace #include <nr_stddef.h> by #include <stm32f10x.h>
	replace all uint32 by uint32_t
	// Cycle per microsecond at 72MHz
	in systick_get_count():
		replace SYSTICK_BASE->CNT by SysTick->VAL

delay.h:
	replace #include <nr_stddef.h> by #include <stm32f10x.h>
	add #include <nr_lib.h>
	replace all uint32 by uint32_t
	remove void delay(unsigned long ms) and void delayMicroseconds(uint32_t us)
	in micros():
		replace "SYSTICK_RELOAD_VAL + 1" by SYSTICK_RELOAD_VAL
		
systick.c:
	replace all uint32 by uint32_t

nvic.h:
	Add #include "stm32f10x.h" into nvic.h
	comment : void nvic_irq_set_priority(nvic_irq_num irqn, uint8 priority);
	comment : void nvic_sys_reset();
	
	comment : nvic_globalirq_enable() function
	add comment : use void __enable_irq(); from core_cm3.h
	comment : nvic_globalirq_disable() function
	add comment : use void __disable_irq(); from core_cm3.h

	comment : static inline void nvic_irq_enable(nvic_irq_num irq_num) function
	add comment : use void NVIC_EnableIRQ(IRQn_Type IRQn); from core_cm3.h
	comment : static inline void nvic_irq_disable(nvic_irq_num irq_num) function
	add comment : use void NVIC_DisableIRQ(IRQn_Type IRQn); from core_cm3.h
nvic.c:
	comment : #include <scb.h>
	replace all uint32 by uint32_t
	comment : void nvic_irq_set_priority(nvic_irq_num irqn, uint8 priority) function
	add comment : use void NVIC_SetPriority(IRQn_Type IRQn, uint32_t priority); from core_cm3.h
	comment : void nvic_sys_reset() function
	add comment : use void NVIC_SystemReset(); from core_cm3.h
	move STM32_NR_INTERRUPTS from nr_stddef.h to nvic.c
	in nvic_init():
		replace nvic_irq_set_priority((nvic_irq_num)i, 0xF);
		by NVIC_SetPriority((IRQn_Type)i, 0xF);
		replace nvic_irq_set_priority(NVIC_SYSTICK, 0xF);
		by NVIC_SetPriority(SysTick_IRQn, 0xF);

nvic.c:
	replace systick_init(SYSTICK_RELOAD_VAL);
	by SysTick_Config(SystemCoreClock / 1000);

nr_lib.h:
	add SYSCLK_FREQ_72MHz from system_stm32f10x.c (115)
	add #define CYCLES_PER_MICROSECOND		72
	add #define SYSTICK_RELOAD_VAL			SYSCLK_FREQ_72MHz / 1000
	move STM32_DELAY_US_MULT from nr_stddef.h to nr_lib.h

Systick usage:
see /STM32F10x_StdPeriph_Lib/Project/STM32F10x_StdPeriph_Examples/SysTick/TimeBase/main.c

https://sourceforge.net/p/libopencm3/mailman/libopencm3-devel/thread/20131216033941.GX9039@home.lan/

