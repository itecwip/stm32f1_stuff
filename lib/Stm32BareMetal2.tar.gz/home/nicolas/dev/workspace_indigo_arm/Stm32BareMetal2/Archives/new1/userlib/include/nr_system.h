/*
 * System initialization
 */

#ifndef _NR_SYSTEM_H
#define _NR_SYSTEM_H

extern void SystemInit(void);

#endif /* _NR_SYSTEM_H */
