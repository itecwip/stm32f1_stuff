#include <stdint.h>
#include "rcc.h"
#include "gpio.h"
#include "init.h"
#include "stk.h"

#define PERIPH_BASE           ((uint32_t)0x40000000) /*!< Peripheral base address in the alias region */

typedef struct
{
	volatile uint32_t CRL;
	volatile uint32_t CRH;
	volatile uint32_t IDR;
	volatile uint32_t ODR;
	volatile uint32_t BSRR;
	volatile uint32_t BRR;
	volatile uint32_t LCKR;
} GPIO_TypeDef;

#define APB1PERIPH_BASE			PERIPH_BASE
#define APB2PERIPH_BASE			(PERIPH_BASE + 0x10000)
#define GPIOA_BASE				(APB2PERIPH_BASE + 0x0800)
#define GPIOC_BASE				(APB2PERIPH_BASE + 0x1000)
#define GPIOA					((GPIO_TypeDef *) GPIOA_BASE)
#define GPIOC					((GPIO_TypeDef *) GPIOC_BASE)

#define BITBAND(addr, bitnum)	((addr & 0xF0000000) + 0x2000000 + ((addr & 0xFFFFF) << 5) + (bitnum << 2))
#define MEM_ADDR(addr)			*((volatile unsigned long  *)(addr))
#define BIT_ADDR(addr, bitnum)	MEM_ADDR(BITBAND(addr, bitnum))

#define GPIOA_ODR_Addr    (GPIOA_BASE+12) //0x4001080C
#define GPIOC_ODR_Addr    (GPIOC_BASE+12) //0x4001100C

#define GPIOA_IDR_Addr    (GPIOA_BASE+8) //0x40010808
#define GPIOC_IDR_Addr    (GPIOC_BASE+8) //0x40011008


#define PAout(n)   BIT_ADDR(GPIOA_ODR_Addr, n)
#define PAin(n)    BIT_ADDR(GPIOA_IDR_Addr, n)

#define PCout(n)   BIT_ADDR(GPIOC_ODR_Addr, n)
#define PCin(n)    BIT_ADDR(GPIOC_IDR_Addr, n)

#define DS18B20_IO_IN()  { GPIOA->CRL &= 0XFFFFFFF0; GPIOA->CRL |= 8 << 0; }
#define DS18B20_IO_OUT() { GPIOA->CRL &= 0XFFFFFFF0; GPIOA->CRL |= 3 << 0; }

#define	DS18B20_DQ_OUT(bit) PAout(bit)
#define	DS18B20_DQ_IN(bit)  PAin(bit)


uint8_t DS18B20_Init(void);
short DS18B20_Get_Temp(void);
void DS18B20_Start(void);
void DS18B20_Write_Byte(uint8_t dat);
uint8_t DS18B20_Read_Byte(void);
uint8_t DS18B20_Read_Bit(void);
uint8_t DS18B20_Check(void);
void DS18B20_Rst(void);




static uint8_t  fac_us = 0;
static uint16_t fac_ms = 0;

// from /MINISTM32/STM32F10x_FWLib/inc/misc.h
// b0:1 Counter enable
// b1:1 Count down to zero assert the SysTick exception
// b2:0 Clock source = AHB/8
#define SysTick_CLKSource_HCLK_Div8    ((uint32_t)0xFFFFFFFB)

//SYSTICK 1/8
//SYSCLK:
void delay_init(uint8_t SYSCLK)
{
	STK->ctrl &= SysTick_CLKSource_HCLK_Div8;
	fac_us = SYSCLK / 8;	// = 9 for 72
	fac_ms = (uint16_t)fac_us * 1000;
}

void delay_us(uint32_t nus)
{
	uint32_t temp;

	STK->load = nus * fac_us;
	STK->val = 0x00;			// start from 0
	STK->ctrl = 0x01;			// start count down
	do {
		temp = STK->ctrl;
	} while(temp & 0x01 && !(temp & (1 << 16)));	// loop while count flag != 0
	STK->ctrl = 0x00;
	STK->val = 0X00;
}

void DS18B20_Rst(void)
{
	DS18B20_IO_OUT(); //SET PA0 OUTPUT
    DS18B20_DQ_OUT(0); //DQ
    delay_us(750);    //750us
    DS18B20_DQ_OUT(1); //DQ=1
	delay_us(15);     //15US
}

uint8_t DS18B20_Check(void)
{
	uint8_t retry=0;
	DS18B20_IO_IN();//SET PA0 INPUT
    while (DS18B20_DQ_IN&&retry<200)
	{
		retry++;
		delay_us(1);
	};
	if(retry>=200)return 1;
	else retry=0;
    while (!DS18B20_DQ_IN&&retry<240)
	{
		retry++;
		delay_us(1);
	};
	if(retry>=240)return 1;
	return 0;
}

uint8_t DS18B20_Read_Bit(void) 			 // read one bit
{
	uint8_t data;
	DS18B20_IO_OUT();//SET PA0 OUTPUT
    DS18B20_DQ_OUT=0;
	delay_us(2);
    DS18B20_DQ_OUT=1;
	DS18B20_IO_IN();//SET PA0 INPUT
	delay_us(12);
	if(DS18B20_DQ_IN)data=1;
    else data=0;
    delay_us(50);
    return data;
}

uint8_t DS18B20_Read_Byte(void)    // read one byte
{
	uint8_t i,j,dat;
    dat=0;
	for (i=1;i<=8;i++)
	{
        j=DS18B20_Read_Bit();
        dat=(j<<7)|(dat>>1);
    }
    return dat;
}

void DS18B20_Write_Byte(uint8_t dat)
 {
	uint8_t j;
	uint8_t testb;
	DS18B20_IO_OUT();//SET PA0 OUTPUT;
    for (j=1;j<=8;j++)
	{
        testb=dat&0x01;
        dat=dat>>1;
        if (testb)
        {
            DS18B20_DQ_OUT=0;// Write 1
            delay_us(2);
            DS18B20_DQ_OUT=1;
            delay_us(60);
        }
        else
        {
            DS18B20_DQ_OUT=0;// Write 0
            delay_us(60);
            DS18B20_DQ_OUT=1;
            delay_us(2);
        }
    }
}

void DS18B20_Start(void)// ds1820 start convert
{
    DS18B20_Rst();
	DS18B20_Check();
    DS18B20_Write_Byte(0xcc);// skip rom
    DS18B20_Write_Byte(0x44);// convert
}

uint8_t DS18B20_Init(void)
{
    /*
     * Enable I/O ports
     */
    /* Enable APB2 clock to I/O port A */
    RCC->apb2enr |= RCC_APB2ENR_IOPAEN_MASK;

    /*
     * Enable LED output
     */
    /* Set PA0 to general purpose push-pull output, max speed 50MHz */
    GPIO_A->crl = (GPIO_A->crl & (~GPIO_CRL_MODE0_MASK) & (~GPIO_CRL_CNF0_MASK)) | (GPIO_MODE_OUTPUT_50MHZ << GPIO_CRL_MODE0_LSB) |
                  (GPIO_CNF_OUTPUT_AF_PUSH_PULL << GPIO_CRL_CNF0_LSB);

	/* Deselect the PA0 Select high */
    GPIO_A->odr ^= GPIO_ODR_ODR0_MASK;
	// GPIO_SetBits(GPIOA,GPIO_Pin_0);

	DS18B20_Rst();
	return DS18B20_Check();
}

short DS18B20_Get_Temp(void)
{
	uint8_t temp;
	uint8_t TL,TH;
	short tem;
    DS18B20_Start();                    // ds1820 start convert
    DS18B20_Rst();
    DS18B20_Check();
    DS18B20_Write_Byte(0xcc);// skip rom
    DS18B20_Write_Byte(0xbe);// convert
    TL=DS18B20_Read_Byte(); // LSB
    TH=DS18B20_Read_Byte(); // MSB

    if(TH>7)
    {
        TH=~TH;
        TL=~TL;
        temp=0;//�¶�Ϊ��
    }else temp=1;//�¶�Ϊ��
    tem=TH; //��ø߰�λ
    tem<<=8;
    tem+=TL;//��õװ�λ
    tem=(float)tem*0.625;//ת��
	if(temp)return tem; //�����¶�ֵ
	else return -tem;
}


void main(void)
{
    /* Basic init */
    init();
    delay_init(72);
    // DS18B20_Rst();

    /*
     * Enable I/O ports
     */
    /* Enable APB2 clock to I/O port C */
    RCC->apb2enr |= RCC_APB2ENR_IOPCEN_MASK;

    /*
     * Enable LED output
     */
    /* Set PC13 to general purpose open-drain output, max speed 2MHz */
    GPIO_C->crh = (GPIO_C->crh & (~GPIO_CRH_MODE13_MASK) & (~GPIO_CRH_CNF13_MASK)) | (GPIO_MODE_OUTPUT_2MHZ << GPIO_CRH_MODE13_LSB) |
                  (GPIO_CNF_OUTPUT_GP_OPEN_DRAIN << GPIO_CRH_CNF13_LSB);

    do {
    	delay_us(250 * 1000);
        GPIO_C->odr ^= GPIO_ODR_ODR13_MASK;
    } while(1);
}
