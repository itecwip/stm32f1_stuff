
**** Build of configuration Default for project Stm32BareMetal2 ****

make -j all 
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -Ilib  -D__ASSEMBLY__ -c -o startup_stm32f103x8.o startup_stm32f103x8.S
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -Ilib  -c -o blink.o blink.c
make -Clib
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -Ilib  -c -o pwm_blink.o pwm_blink.c
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -Ilib  -c -o usart_hello.o usart_hello.c
make[1]: Entering directory `/home/nicolas/dev/workspace_indigo_arm/Stm32BareMetal2/lib'
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb  -c -o init.o init.c
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -Ilib  -D__ASSEMBLY__ -MM startup_stm32f103x8.S > startup_stm32f103x8.d
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -Ilib  -MM pwm_blink.c > pwm_blink.d
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -Ilib  -MM usart_hello.c > usart_hello.d
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb  -MM init.c > init.d
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -Ilib  -MM blink.c > blink.d
arm-none-eabi-ar rcs libnr_stm32f1_lib.a init.o
make[1]: Leaving directory `/home/nicolas/dev/workspace_indigo_arm/Stm32BareMetal2/lib'
arm-none-eabi-ld -T stm32f103x8.ld -Llib -o blink.elf startup_stm32f103x8.o blink.o -lnr_stm32f1_lib
arm-none-eabi-ld -T stm32f103x8.ld -Llib -o pwm_blink.elf startup_stm32f103x8.o pwm_blink.o -lnr_stm32f1_lib
arm-none-eabi-ld -T stm32f103x8.ld -Llib -o usart_hello.elf startup_stm32f103x8.o usart_hello.o -lnr_stm32f1_lib

arm-none-eabi-objcopy -O binary blink.elf blink.bin

arm-none-eabi-objcopy -O binary pwm_blink.elf pwm_blink.bin

arm-none-eabi-objcopy -O binary usart_hello.elf usart_hello.bin
arm-none-eabi-objdump -D blink.elf > blink.list
arm-none-eabi-objdump -D pwm_blink.elf > pwm_blink.list
arm-none-eabi-objdump -D usart_hello.elf > usart_hello.list
arm-none-eabi-size pwm_blink.elf
arm-none-eabi-size blink.elf
arm-none-eabi-size usart_hello.elf
   text	   data	    bss	    dec	    hex	filename
    694	      0	      0	    694	    2b6	pwm_blink.elf
   text	   data	    bss	    dec	    hex	filename
    658	      0	      0	    658	    292	blink.elf
   text	   data	    bss	    dec	    hex	filename
    762	      0	      0	    762	    2fa	usart_hello.elf

**** Build Finished ****

