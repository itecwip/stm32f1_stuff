#include "nr_lib.h"

#include "nvic.h"
#include "systick.h"
#include "delay.h"
#include "onewire.h"

//=============================================================================
// Defines
//=============================================================================
#define USART_RX_GPIO GPIOA
#define USART_RX_PIN  10

#define USART_TX_GPIO GPIOA
#define USART_TX_PIN  9


uint8_t text[] = "STM32VLDISCOVERY tutorial\r\n";
static onewire_search_t		ow;
static char					str[CVT_DATA_LEN];
static char					strbuff[CVT_BUFF_LEN];

//=============================================================================
//
//=============================================================================
void USART_PutChar(uint8_t ch)
{
	while(!(USART1->SR & USART_SR_TXE));
	USART1->DR = ch;
}
//=============================================================================
//
//=============================================================================
void USART_PutString(uint8_t *str)
{
	while(*str != 0)
	{
		USART_PutChar((uint8_t)*str);
		str++;
	}
}



//=============================================================================
// main function
//=============================================================================
int main(void)
{
	uint8_t		addr[8];
	uint8_t		data[12];

    SystemInit(); 			 // SYSCLK_FREQ_72MHz
	nvic_init();
    SysTick_Config(SYSTICK_RELOAD_VAL);

    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_USART1EN;
	USART_RX_GPIO->CRH = (USART_RX_GPIO->CRH & CONFMASKH(USART_RX_PIN)) | GPIOPINCONFH(USART_RX_PIN,   GPIOCONF(GPIO_MODE_INPUT, GPIO_CNF_INPUT_PULLUPDOWN));
	USART_TX_GPIO->CRH = (USART_TX_GPIO->CRH & CONFMASKH(USART_TX_PIN)) | GPIOPINCONFH(USART_TX_PIN,   GPIOCONF(GPIO_MODE_OUTPUT2MHz, GPIO_CNF_AFIO_PUSHPULL));
	USART1->BRR = (SYSCLK_FREQ_72MHz / 9600);
	USART1->CR1 |= (USART_CR1_RE | USART_CR1_TE);
	USART1->CR1 |= USART_CR1_UE;


	USART_PutString((uint8_t *)"One wire test:\r\n");

	onewire_init();
	onewire_reset_search(&ow);

	do {
		if (!onewire_search(&ow, addr)) {
			USART_PutString((uint8_t *)"No more addresses.\r\n");
			onewire_reset_search(&ow);
			delay_ms(250);
		}
		if (onewire_crc8(addr, 7) != addr[7]) {
			USART_PutString((uint8_t *)"CRC is not valid!");
			break;
		}
		// the first ROM byte indicates which chip
		if (addr[0] != 0x28) {
			USART_PutString((uint8_t *)"Device is not a DS18x20 family device.");
			break;
		}
		onewire_reset();
		onewire_select(addr);
		onewire_write(0x44, 1);        // start conversion, with parasite power on at the end

		delay_ms(1000);     // maybe 750ms is enough, maybe not
		// we might do a ds.depower() here, but the reset will take care of it.

		onewire_reset();
		onewire_select(addr);
		onewire_write(0xBE, 0);         // Read Scratchpad

		for (uint8_t i = 0; i < 9; i++) {           // we need 9 bytes
			data[i] = onewire_read();
		}
		int16_t raw = (data[1] << 8) | data[0];
		uint8_t cfg = (data[4] & 0x60);
		// at lower res, the low bits are undefined, so let's zero them
		if (cfg == 0x00) raw = raw & ~7;  // 9 bit resolution, 93.75 ms
		else if (cfg == 0x20) raw = raw & ~3; // 10 bit res, 187.5 ms
		else if (cfg == 0x40) raw = raw & ~1; // 11 bit res, 375 ms
		//// default is 12 bit resolution, 750 ms conversion time
		nr_convert2dec(raw / 16, str);
		nr_convertdata2hex(addr, strbuff);
		USART_PutString((uint8_t *)"[");
		USART_PutString((uint8_t *)strbuff);
		USART_PutString((uint8_t *)"] Temperature = ");
		USART_PutString((uint8_t *)str);
		USART_PutString((uint8_t *)"�C\r\n");
	} while (1);

	USART_PutString((uint8_t *)"End of program.");

	return 0;

//    while (1) {
//        /* Wait for Enter to be pressed */
//        do {
//            /* Wait for receive register to fill */
//            while (!(USART1->SR & USART_SR_RXNE));
//            /* Read the byte */
//            c = USART1->DR;
//        } while (c != '\r');
//
//        /* Output the message */
//        USART_PutString(text);
//    }
}
