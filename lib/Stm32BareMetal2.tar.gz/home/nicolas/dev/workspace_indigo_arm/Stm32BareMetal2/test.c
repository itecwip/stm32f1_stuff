#include "nr_lib.h"

#include "nvic.h"
#include "systick.h"
#include "delay.h"


static void gpio_setup(void)
{
	/* Enable GPIOC clock. */
	RCC->APB2ENR = RCC_APB2ENR_IOPCEN;
	// Set PC_12 to output

	/* Set GPIO13 (in GPIO port C) to 'output push-pull'. */
	GPIOC->CRH &= ~(GPIO_CRH_MODE13 | GPIO_CRH_CNF13);
	GPIOC->CRH |= GPIO_CRH_MODE13;
}

int main(void)
{
	SystemInit(); 			 // SYSCLK_FREQ_72MHz
	nvic_init();
    systick_init(SYSTICK_RELOAD_VAL);

	gpio_setup();

	while(1) {
		// LED off - GPIO_ResetBits(GPIOC,GPIO_Pin_13);
		PCout(13) = 0;
		// GPIOC->BSRR = (1 << 13);
		delay_ms(300);
		// LED on - GPIO_SetBits(GPIOC,GPIO_Pin_13);
		PCout(13) = 1;
		// GPIOC->BRR = (1 << 13);
		delay_ms(300 );
	}
}

