Programmation du STM32F103C8T6 avec la cl� USB stlink-v2
========================================================

set WORKAREASIZE 0x10000

Brancher la cl� stlink-v2 connect�e la carte STM32F103C8T6.
Lancer 2 consoles

Sur la premi�re:
----------------
$ cd /home/nicolas/dev/arm/tools/bin
$ ./run_stm.sh

Sur la deuxi�me:
----------------
$ telnet 127.0.0.1 4444

> halt

# dump du firmware existant 64Kb
> dump_image stm32f103c8t6.bin 0x08000000 0x0ffff

> halt
> flash probe 0
> stm32f1x mass_erase 0
> flash erase_check 0
> flash write_bank 0 /home/nicolas/dev/workspace_indigo_arm/LibOpenCM3Test/build/test_ledpc13.bin 0
> reset run


flash write_image erase <fichier_hex> 0

reset

exit

$

Liste des images (*.hex)

flash write_bank 0 /home/nicolas/dev/workspace_indigo_arm/LibOpenCM3Test/build/test_ledpc13.bin 0

flash write_bank 0 /home/nicolas/dev/workspace_indigo_arm/Stm32BareMetal/blinker01.gcc.thumb.bin 0
flash write_bank 0 /home/nicolas/dev/workspace_indigo_arm/Stm32BareMetal/blinker01.gcc.thumb2.bin 0


https://github.com/dwelch67/maple_samples
http://electronics.stackexchange.com/questions/30736/stm32f2-makefile-linker-script-and-start-up-file-combination-without-commercia

