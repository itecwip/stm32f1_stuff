//=============================================================================
// STM32VLDISCOVERY tutorial
// Lesson 9. Analog to digital converter (ADC) with direct memory access (DMA)
// Copyright : Radoslaw Kwiecien
// http://en.radzio.dxp.pl
// e-mail : radek(at)dxp.pl
//=============================================================================
#include "stm32f10x.h"
#include "antilib_gpio.h"
#include "antilib_adc.h"
//=============================================================================
// Defines
//=============================================================================
#define USART_RX_GPIO GPIOA
#define USART_RX_PIN 10

#define USART_TX_GPIO GPIOA
#define USART_TX_PIN 9
//=============================================================================
// Send single char
//=============================================================================
void USART_PutChar(uint8_t ch)
{
  while(!(USART1->SR & USART_SR_TXE));
  USART1->DR = ch;
}
//=============================================================================
// Send text
//=============================================================================
void USART_PutString(uint8_t * str)
{
while(*str != 0)
  {
  USART_PutChar(*str);
  str++;
  }
}
//=============================================================================
// Global variables
//=============================================================================
vu16 AIN[4];  // table for conversions results
char str[32]; // buffer for text
//=============================================================================
// main function
//=============================================================================
int main(void)
{
vu32 dly;
RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPCEN | RCC_APB2ENR_AFIOEN | RCC_APB2ENR_ADC1EN | RCC_APB2ENR_USART1EN;
RCC->AHBENR |= RCC_AHBENR_DMA1EN;

#if (USART_RX_PIN > 7)
USART_RX_GPIO->CRH = (USART_RX_GPIO->CRH & CONFMASKH(USART_RX_PIN)) | GPIOPINCONFH(USART_RX_PIN, GPIOCONF(GPIO_MODE_INPUT, GPIO_CNF_INPUT_PULLUPDOWN));
#else
USART_RX_GPIO->CRL = (USART_RX_GPIO->CRL & CONFMASKL(USART_RX_PIN)) | GPIOPINCONFL(USART_RX_PIN, GPIOCONF(GPIO_MODE_INPUT, GPIO_CNF_INPUT_PULLUPDOWN));
#endif

#if (USART_TX_PIN > 7)
USART_TX_GPIO->CRH = (USART_TX_GPIO->CRH & CONFMASKH(USART_TX_PIN)) | GPIOPINCONFH(USART_TX_PIN, GPIOCONF(GPIO_MODE_OUTPUT2MHz, GPIO_CNF_AFIO_PUSHPULL));
#else
USART_TX_GPIO->CRL = (USART_TX_GPIO->CRL & CONFMASKL(USART_TX_PIN)) | GPIOPINCONFL(USART_TX_PIN, GPIOCONF(GPIO_MODE_OUTPUT2MHz, GPIO_CNF_AFIO_PUSHPULL));
#endif

GPIOA->CRL = (GPIOA->CRL & 0xFFFF0000) |
             GPIOPINCONFL(0, GPIOCONF(GPIO_MODE_INPUT, GPIO_CNF_INPUT_ANALOG)) |
             GPIOPINCONFL(1, GPIOCONF(GPIO_MODE_INPUT, GPIO_CNF_INPUT_ANALOG)) |
             GPIOPINCONFL(2, GPIOCONF(GPIO_MODE_INPUT, GPIO_CNF_INPUT_ANALOG)) |
             GPIOPINCONFL(3, GPIOCONF(GPIO_MODE_INPUT, GPIO_CNF_INPUT_ANALOG));

ADC1->CR2 = ADC_CR2_ADON | // turn on ADC
            ADC_CR2_CONT | // enable continuos mode
            ADC_CR2_DMA;   // enable DMA mode

ADC1->CR1 = ADC_CR1_SCAN; // enable scan mode

ADC1->SQR1 = ADC_SEQUENCE_LENGTH(3); // four channels in sequence

ADC1->SQR3 = ADC_SEQ1(0) | // channel 0 is first in sequence
             ADC_SEQ2(1) | // channel 1 is second in sequence
             ADC_SEQ3(2) | // channel 2 is third in sequence
             ADC_SEQ4(3) ; // channel 3 is fourth in sequence

ADC1->SMPR2 = ADC_SAMPLE_TIME0(SAMPLE_TIME_239_5) | // sample time for first channel in sequence
              ADC_SAMPLE_TIME1(SAMPLE_TIME_239_5) | // sample time for second channel in sequence
              ADC_SAMPLE_TIME2(SAMPLE_TIME_239_5) | // sample time for third channel in sequence
              ADC_SAMPLE_TIME3(SAMPLE_TIME_239_5) ; // sample time for fourth channel in sequence

DMA1_Channel1->CPAR  = (uint32_t)(&(ADC1->DR)); // peripheral (source) address
DMA1_Channel1->CMAR  = (uint32_t)AIN; // memory (desination) address
DMA1_Channel1->CNDTR = 4; // 4 transfers

DMA1_Channel1->CCR |= DMA_CCR1_CIRC |    // circular mode enable
                      DMA_CCR1_MINC |    // memory increment mode enable
                      DMA_CCR1_MSIZE_0 | // memory size 16 bits
                      DMA_CCR1_PSIZE_0;  // peripheral size 16 bits

DMA1_Channel1->CCR |= DMA_CCR1_EN ; // Enable channel

ADC1->CR2 |= ADC_CR2_ADON; // Turn on conversion

USART1->CR1 = USART_CR1_UE | USART_CR1_TE;
USART1->BRR = (SystemCoreClock / 115200);

USART_PutString("STM32VLDISCOVERY tutorial lesson 9\r");

do{
  sprintf(str, "0:%d\t\t1:%d\t\t2:%d\t\t3:%d\r", AIN[0], AIN[1], AIN[2], AIN[3]);
  USART_PutString(str);
  for(dly = 0; dly < 1000000; dly++);
}while(1);

}
//=============================================================================
// End of file
//=============================================================================
