
#include "nr_nvic.h"
#include "nr_systick.h"
#include "nr_delay.h"
#include "antilib_adc.h"

#define LED_BLUE_GPIO		GPIOB
#define LED_BLUE_PIN		0

#define AIN0_GPIO			GPIOA
#define AIN0_PIN			1

int main(void)
{
    SystemInit(); 			 // SYSCLK_FREQ_72MHz
	nvic_init();
    SysTick_Config(SYSTICK_RELOAD_VAL);

	RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_AFIOEN | RCC_APB2ENR_ADC1EN;
	RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;

	LED_BLUE_GPIO->CRL = (LED_BLUE_GPIO->CRL & CONFMASKL(LED_BLUE_PIN)) | GPIOPINCONFL(LED_BLUE_PIN, GPIOCONF(GPIO_MODE_OUTPUT2MHz, GPIO_CNF_AFIO_PUSHPULL));
	AIN0_GPIO->CRL = (AIN0_GPIO->CRL & CONFMASKL(AIN0_PIN)) | GPIOPINCONFL(AIN0_PIN, GPIOCONF(GPIO_MODE_INPUT, GPIO_CNF_INPUT_ANALOG));

	AFIO->MAPR &= ~AFIO_MAPR_TIM3_REMAP; // TIM3 : no remap (PB0 -> CH3)

	TIM3->PSC = 71;		// Set prescaler to 24 (PSC + 1) 72MHz / 72 = 1MHz
	TIM3->ARR = 4096;	// Auto reload value 4096 (PWM resolution 12-bits)
	TIM3->CCR3 = 100;		// Start value channel 3

	TIM3->CCMR2 = TIM_CCMR2_OC3M_2 | TIM_CCMR2_OC3M_1; // PWM mode on channel 3

	TIM3->CCER = TIM_CCER_CC3E;		// Enable compare on channel 3
	TIM3->CR1 = TIM_CR1_CEN;		// Enable timer

	ADC1->CR2 = ADC_CR2_ADON | ADC_CR2_CONT;			// Turn on ADC, enable continuos mode
	ADC1->SQR1 = ADC_SEQUENCE_LENGTH(0);				// One channel in sequence
	ADC1->SQR3 = ADC_SEQ1(0);							// ADC channel 0 is first in sequence
	ADC1->SMPR2 = ADC_SAMPLE_TIME0(SAMPLE_TIME_239_5);	// sample time for first channel

	ADC1->CR1 = ADC_CR1_EOCIE;							// Enable interrupt form End Of Conversion
	NVIC_EnableIRQ(ADC1_2_IRQn);						// Enable interrupt form ACD1 peripheral

	ADC1->CR2 |= ADC_CR2_ADON;							// Turn on conversion

	while (1) {

	}
}


void ADC1_2_IRQHandler(void) __attribute__ ((isr));
void ADC1_2_IRQHandler(void) {
	if (ADC1->SR & ADC_SR_EOC) {
	//	TIM3->CCR3 = ADC1->DR;
	}
}

