#ifndef _NR_DELAY_H_
#define _NR_DELAY_H_

#include "stm32f10x.h"
#include "nr_systick.h"
#include "nr_lib.h"

/**
 * Returns time (in milliseconds) since the beginning of program
 * execution. On overflow, restarts at 0.
 * @see micros()
 */
static inline uint32_t millis(void) {
    return systick_uptime_millis;
}

/**
 * Returns time (in microseconds) since the beginning of program
 * execution.  On overflow, restarts at 0.
 * @see millis()
 */
static inline uint32_t micros(void) {
	uint32_t ms;
	uint32_t cycle_cnt;

    do {
        ms = systick_uptime_millis;
        cycle_cnt = systick_get_count();
    } while (ms != systick_uptime_millis);

#define US_PER_MS               1000
    /* SYSTICK_RELOAD_VAL is 1 less than the number of cycles it
     * actually takes to complete a SysTick reload */
    return ((ms * US_PER_MS) +
            (SYSTICK_RELOAD_VAL - cycle_cnt) / CYCLES_PER_MICROSECOND);
#undef US_PER_MS
}


#endif /* _NR_DELAY_H_ */
