#ifndef _NR_ADC_H_
#define _NR_ADC_H_

#include "stm32f10x.h"

/** System elapsed time, in milliseconds */
extern volatile uint16_t adc_last_value;

/**
 * @brief ADC1 Initialization
 */
void ADC_Init(void);



/**
 * @brief Returns the last converted value
 */
__attribute__((always_inline))
static inline uint16_t getADCLastValue(void) {
    return adc_last_value;
}

/**
 * @brief Start an ADC conversion
 */
__attribute__((always_inline))
static inline void startADCConversion(void) {
	ADC1->CR2  |= (1 << 22);			// start SW conversion
}


#endif /* _NR_ADC_H_ */
