#ifndef _NR_ADC_H_
#define _NR_ADC_H_

#include "stm32f10x.h"


#define ADC_CH1  		1
#define ADC_CH_TEMP  	16		// Internal CPU temperature

/**
 * @brief ADC1 Initialization
 */
void		Adc_Init(void);

/**
 * Get ADC value
 * ch: channel number [0..16]
 */
uint16_t 	Get_Adc(uint8_t ch);

/**
 * Return the average of 'times' ADC read
 * ch: channel number [0..16]
 * times : Number of reads
 */
uint16_t	Get_Adc_Average(uint8_t ch,uint8_t times);


#endif /* _NR_ADC_H_ */
