#ifndef __ADC_H
#define __ADC_H	
#include "stm32f10x.h"


#define ADC_CH1  		1  			//通道1		 	    
#define ADC_CH_TEMP  	16 			//温度传感器通道
  		


void Adc_Init(void); 				//ADC通道初始化
uint16_t  Get_Adc(uint8_t ch); 				//获得某个通道值
uint16_t Get_Adc_Average(uint8_t ch,uint8_t times);//得到某个通道10次采样的平均值


#endif 















