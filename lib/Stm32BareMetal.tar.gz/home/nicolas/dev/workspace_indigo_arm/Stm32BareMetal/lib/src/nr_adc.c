/**
 * ADC1 utilities
 */

#include "nr_adc.h"

volatile volatile uint16_t adc_last_value;

void ADC_Init(void) {
	RCC->APB2ENR |= (1 << 4);			// enable peripheral clock for GPIOC
	GPIOC->CRL &= ~0xF0000000;			// Configure PC15 as ADC.14 input

	RCC->APB2ENR |= (1 << 9);			// enable peripheral clock for ADC1

	ADC1->SQR1 = 0x00000000;			// Regular channel 1 conversion
	ADC1->SQR2 = 0x00000000;			// Clear register
	ADC1->SQR3 = (14 << 0);				// SQ1 = channel 14
	ADC1->SMPR1 = (5 << 12);			// sample time channel 14 55,5 cycles
	ADC1->CR1 = (1 << 8) |				// Scan mode on
				(1 << 5);				// EOC interrupt enable
	ADC1->CR2 = (1 << 20) |				// Enable external trigger
				(7 << 17) |				// EXTSEL = SWSTART
				(1 << 0);				// ADC enable
	ADC1->CR2 |= (1 << 3);				// Reset calibration
	while (ADC1->CR2 & (1 << 3));		// wait until reset finished

	ADC1->CR2 |= (1 << 2);				// start calibration
	while (ADC1->CR2 & (1 << 2));		// wait until calibration finished

	NVIC_EnableIRQ (ADC1_2_IRQn);		// enable ADC Interrupt
}

void ADC1_2_IRQHandler(void) __attribute__ ((isr));
void ADC1_2_IRQHandler(void) {
	if (ADC1->SR & (1 << 1))  {					// ADC1 EOC interrupt?
		adc_last_value = (ADC1->DR) & 0xFFF;	// Read Conversion Result
		ADC1->SR &= ~(1 << 1);					// clear EOC interrupt
	}
}
