#ifndef _NR_NVIC_H_
#define _NR_NVIC_H_


#include "stm32f10x.h"

#define STM32_NR_INTERRUPTS      43


void nvic_init(/*uint32 address, uint32 offset*/);

/**
 * brief Quickly disable all interrupts.
 *
 * Calling this function is significantly faster than calling
 * nvic_irq_disable() in a loop.
 */
// static inline void nvic_irq_disable_all(void);

static inline void nvic_irq_disable_all(void) {
    /* Even low-density devices have over 32 interrupt lines. */
	NVIC->ICER[0] = 0xFFFFFFFF;
	NVIC->ICER[1] = 0xFFFFFFFF;
}


#endif /* _NR_NVIC_H_ */
