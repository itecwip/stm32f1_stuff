/**
 * Nested vector interrupt controller support.
 */
#include "nr_nvic.h"
#include "nr_lib.h"

/**
 * @brief Initialize the NVIC, setting interrupts to a default priority.
 */
void nvic_init(/*uint32 address, uint32 offset*/) {
    // NRO : setup in nr_lib.SystemInit()
    // nvic_set_vector_table(address, offset);

    /*
     * Lower priority level for all peripheral interrupts to lowest
     * possible.
     */
    for (uint32_t i = 0; i < STM32_NR_INTERRUPTS; i++) {
    	NVIC_SetPriority((IRQn_Type)i, 0xF);
    }

    /* Lower systick interrupt priority to lowest level */
    NVIC_SetPriority(SysTick_IRQn, 0xF);
}

/**
 * @brief Set the vector table base address.
 *
 * For stand-alone products, the vector table base address is normally
 * the start of Flash (0x08000000).
 *
 * @param address Vector table base address.
 * @param offset Offset from address.  Some restrictions apply to the
 *               use of nonzero offsets; see the ARM Cortex M3
 *               Technical Reference Manual.
 */
//void nvic_set_vector_table(uint32 address, uint32 offset) {
//    SCB_BASE->VTOR = address | (offset & 0x1FFFFF80);
//}

