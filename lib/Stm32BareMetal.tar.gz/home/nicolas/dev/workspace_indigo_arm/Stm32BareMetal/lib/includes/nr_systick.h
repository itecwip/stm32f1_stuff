#ifndef _NR_SYSTICK_H_
#define _NR_SYSTICK_H_

#include "stm32f10x.h"

/** System elapsed time, in milliseconds */
extern volatile uint32_t systick_uptime_millis;

/**
 * @brief Returns the system uptime, in milliseconds.
 */
__attribute__((always_inline))
static inline uint32_t systick_uptime(void) {
    return systick_uptime_millis;
}

/**
 * @brief Returns the current value of the SysTick counter.
 */
__attribute__((always_inline))
static inline uint32_t systick_get_count(void) {
    return SysTick->VAL;
}


#endif /* _NR_SYSTICK_H_ */
