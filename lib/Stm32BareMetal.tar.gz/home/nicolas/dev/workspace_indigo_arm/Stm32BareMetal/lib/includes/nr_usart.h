#ifndef _NR_USART_H_
#define _NR_USART_H_

#include "stm32f10x.h"

#define USART_RX_GPIO GPIOA
#define USART_RX_PIN  10

#define USART_TX_GPIO GPIOA
#define USART_TX_PIN  9


void USART_PutChar(char ch);
void USART_PutString(char *str);

void USART_Init();


#endif /* _NR_USART_H_ */
