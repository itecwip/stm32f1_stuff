#include <stdint.h>

void dummy (uint32_t);


/**
 * @brief  LDR command
 *
 * @param  uint32_t	*address
 * @return uint32_t value of (*address)
 */
__attribute__((always_inline))
static inline uint32_t GetData32(uint32_t address)
{
    register uint32_t result;

   __asm__ __volatile__ ("ldr %0, [%1]" : "=r" (result) : "r" (address) : "cc");
   return(result);
}

/**
 * @brief  STR command
 *
 * @param  uint32_t *address
 * @param  uint32_t value to store
 * @return none
 */
__attribute__((always_inline))
static inline void PutData32(uint32_t address, uint32_t value)
{
	__asm__ __volatile__ ("str %0, [%1]" :: "r" (value), "r" (address) : "cc", "memory");
}

__attribute__((always_inline))
static inline void PutGetSet32(uint32_t address, uint32_t value)
{
	__asm__ __volatile__ (
			"ldr r2, [%0]	\n"
			"orr r2, %1		\n"
			"str r2, [%0]	\n"
			:: "r" (address), "r" (value) : "r2", "cc", "memory");
}

__attribute__((always_inline))
static inline void PutGetClear32(uint32_t address, uint32_t value)
{
	__asm__ __volatile__ (
			"ldr r2, [%0]	\n"
			"bic r2, %1		\n"
			"str r2, [%0]	\n"
			:: "r" (address), "r" (value) : "r2", "cc", "memory");
}

__attribute__((always_inline))
static inline void PutGetSetMask32(uint32_t address, uint32_t mask, uint32_t value)
{
	__asm__ __volatile__ (
			"ldr r3, [%0]	\n"
			"bic r3, %1		\n"
			"orr r3, %2		\n"
			"str r3, [%0]	\n"
			:: "r" (address), "r" (mask), "r" (value) : "r3", "cc", "memory");
}

__attribute__((always_inline))
static inline void PutData16(uint32_t address, uint16_t value)
{
	__asm__ __volatile__ ("strh %0, [%1]" :: "r" (value), "r" (address) );
}



#define RCC_BASE 0x40021000

#define RCC_APB2ENR (RCC_BASE+0x18)


#define GPIOB_BASE 0x40011000

#define GPIOB_CRL  (GPIOB_BASE+0x00)
#define GPIOB_CRH  (GPIOB_BASE+0x04)
#define GPIOB_IDR  (GPIOB_BASE+0x08)
#define GPIOB_ODR  (GPIOB_BASE+0x0C)
#define GPIOB_BSRR (GPIOB_BASE+0x10)
#define GPIOB_BRR  (GPIOB_BASE+0x14)
#define GPIOB_LCKR (GPIOB_BASE+0x18)

int notmain(void)
{
	uint32_t ra;

	PutGetSet32(RCC_APB2ENR, 1 << 4); 					// enable GPIOC
	PutGetSetMask32(GPIOB_CRH, 0xF << 20, 0x1 << 20);

    while(1) {
    	PutData32(GPIOB_BSRR,0x00002000);
        for (ra=0;ra<100000;ra++) {
        	dummy(ra);
        }
        PutData32(GPIOB_BSRR,0x20000000);
        for(ra=0;ra<100000;ra++) {
        	dummy(ra);
        }
        PutData32(GPIOB_BSRR,0x00002000);
        for(ra=0;ra<100000;ra++) {
        	dummy(ra);
        }
        PutData32(GPIOB_BSRR,0x20000000);
        for(ra=0;ra<100000;ra++) {
        	dummy(ra);
        }
        PutData32(GPIOB_BSRR,0x00002000);
        for(ra=0;ra<100000;ra++) {
        	dummy(ra);
        }
        PutData32(GPIOB_BSRR,0x20000000);
        for(ra=0;ra<400000;ra++) {
        	dummy(ra);
        }
    }
    return(0);
}
