void PUT32 ( unsigned int, unsigned int );
unsigned int GET32 ( unsigned int );
void dummy ( unsigned int );

#define RCC_BASE 0x40021000

#define RCC_APB2ENR (RCC_BASE+0x18)


#define GPIOB_BASE 0x40011000

#define GPIOB_CRL  (GPIOB_BASE+0x00)
#define GPIOB_CRH  (GPIOB_BASE+0x04)
#define GPIOB_IDR  (GPIOB_BASE+0x08)
#define GPIOB_ODR  (GPIOB_BASE+0x0C)
#define GPIOB_BSRR (GPIOB_BASE+0x10)
#define GPIOB_BRR  (GPIOB_BASE+0x14)
#define GPIOB_LCKR (GPIOB_BASE+0x18)

int notmain ( void )
{
    unsigned int ra;

    ra = GET32(RCC_APB2ENR);
    ra |= 1 << 4;   //GPIOC
    PUT32(RCC_APB2ENR, ra);

    //pb1 output
    ra = GET32(GPIOB_CRH);
    ra &= ~(0xF00000);
    //mode 01  cnf 00
    //0001
    ra |= 0x100000;
    PUT32(GPIOB_CRH, ra);

    while(1)
    {
        PUT32(GPIOB_BSRR,0x00002000);
        for(ra=0;ra<100000;ra++) dummy(ra);
        PUT32(GPIOB_BSRR,0x20000000);
        for(ra=0;ra<100000;ra++) dummy(ra);
        PUT32(GPIOB_BSRR,0x00002000);
        for(ra=0;ra<100000;ra++) dummy(ra);
        PUT32(GPIOB_BSRR,0x20000000);
        for(ra=0;ra<100000;ra++) dummy(ra);
        PUT32(GPIOB_BSRR,0x00002000);
        for(ra=0;ra<100000;ra++) dummy(ra);
        PUT32(GPIOB_BSRR,0x20000000);
        for(ra=0;ra<400000;ra++) dummy(ra);
    }
    return(0);
}
