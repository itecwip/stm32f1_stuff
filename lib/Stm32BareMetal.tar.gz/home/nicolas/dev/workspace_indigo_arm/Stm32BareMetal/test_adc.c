
#include "nr_nvic.h"
#include "nr_systick.h"
#include "nr_delay.h"
#include "nr_usart.h"
#include "adc.h"

#define LED_BLUE_GPIO		GPIOB
#define LED_BLUE_PIN		0

#define AIN0_GPIO			GPIOA
#define AIN0_PIN			1

static char		str[CVT_DATA_LEN];


int main(void)
{
	uint16_t adcx;

    SystemInit(); 			 // SYSCLK_FREQ_72MHz
	nvic_init();
    SysTick_Config(SYSTICK_RELOAD_VAL);
    USART_Init();
    Adc_Init();

	while(1)
	{
		adcx = Get_Adc(1);
		nr_convert2dec(adcx, str);
		USART_PutString("ADC value = ");
		USART_PutString(str);
		USART_PutString("\r\n");

		delay_ms(500);
	}

}
