#include "nr_lib.h"

#include "nr_nvic.h"
#include "nr_systick.h"
#include "nr_delay.h"
#include "nr_usart.h"
#include "nr_adc.h"

//=============================================================================
// Defines
//=============================================================================

static char		str[CVT_DATA_LEN];


//=============================================================================
// main function
//=============================================================================
int main(void)
{
	uint16_t	value;

    SystemInit(); 			 // SYSCLK_FREQ_72MHz
	nvic_init();
    SysTick_Config(SYSTICK_RELOAD_VAL);
    USART_Init();
    ADC_Init();

	USART_PutString("ADC test:\r\n");

	do {
		startADCConversion();
		delay_ms(1000);
		value = getADCLastValue();
		nr_convert2dec(value, str);
		USART_PutString("ADC value = ");
		USART_PutString(str);
		USART_PutString("\r\n");
	} while(1);

	USART_PutString("End of program.");

	return 0;
}
