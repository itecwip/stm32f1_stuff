//__________________________________________________________
// projet/TP_GPIO/      MAIN.C
// Tentative de faire clignoter une diode
// BINOME :
// ETAT : compilé et testé
// MODIFICATIONS :
// 14/09 : suppression des options de compilation et nettoyage des TODO
//__________________________________________________________

#include "stm32f10x.h"


int main (void)
{
	//char flipflop = 1;
	
 	// Cette ligne est nécessaire pour le bon fonctionnement de la carte, pour l'instant oubliez la !
 	(RCC->APB2ENR)|= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_IOPCEN;

	// CRH = 1111 1111 : 1111 1111 : 1111 1111 : 1111 1111 
	GPIOB->CRH = 0xFFFFFFFF;
	GPIOA->CRL = 0xFFFFFFFF;
	//__ configuration du port PB.9 en sortie (output push-pull)
	// CRH = xxxx xxxx : xxxx xxxx : xxxx xxxx : 0001 xxxx 	
	GPIOB->CRH = ((GPIOB->CRH & ~(0xFF0))| 0x110);
	GPIOA->CRL = ((GPIOA->CRL & ~(0xF)) | (0x04));
	// TODO : Qu'est-ce que veut dire (x << y) ?   Décalage de bits Ok
	// TODO : Pour ne pas toucher aux bits autres que ceux de configruation du port 9, il faut faire un masque. Faites le ! Ok
	 
	// Faire clignoter la diode sur le port PB.9
	while(1)
	{
		if ((GPIOA->IDR & 0x01) == 0x00) {
			GPIOB->BSRR = (0x01 << 10);
		}	else {
			GPIOB->BSRR = (0x01 << 26); 
		}
		if ((GPIOB->ODR & (0x01 << 9))== 0x00) {
		// ODR = xxxx xxxx : xxxx xxxx : xxxx xx1x : xxxx xxxx 
			GPIOB->BSRR = (0x01 << 9); 
			// TODO : Comment faire pour ne changer que le bit 9 ? Ok
			// TODO : Comment faier pour se passer du flipflop en utilisant directement la valeur de ODR ? Ok
		} else {
		// ODR=xxxx xxxx | xxxx xxxx | xxxx xx0x |xxxx xxxx 
			GPIOB->BSRR = (0x01 << 25); 
		}
	}

	return 0;
}

void Port_IO_Init_Output( GPIO_TypeDef * Port, u8 Broche)
{
	if ( Broche < 8) {
	Port->CRL = ((Port->CRL & ~(0xF << Broche*4)) | (0x01 << Broche*4));
	}
	else {
	Port->CRH	= ((Port->CRL & ~(0xF << (Broche-8)*4)) | (0x01 << (Broche-8)*4));
	}
}

void Port_IO_Init_Input( GPIO_TypeDef * Port, u8 Broche)
{
	if ( Broche < 8) {
	Port->CRL = ((Port->CRL & ~(0xF << Broche*4)) | (0x04 << Broche*4));
	}
	else {
	Port->CRH	= ((Port->CRL & ~(0xF << (Broche-8)*4)) | (0x04 << (Broche-8)*4));
	}
}

void Port_IO_Set(GPIO_TypeDef * Port, u8 Broche)
{
	Port->BSRR = (0x01 << Broche); 
}

void Port_IO_Reset(GPIO_TypeDef * Port, u8 Broche)
{
	Port->BSRR = (0x01 << (Broche + 16)); 
}

void Port_IO_Blink(GPIO_TypeDef * Port, u8 Broche)
{
	Port->ODR ^= (0x01 << Broche);
}

unsigned int Port_IO_Read(GPIO_TypeDef * Port, u8 Broche)
{
	unsigned int reading; 
	if (Broche < 8) {		
		if (Port->CRL & (0x3 << Broche*4) = 0x00) {
			if (Port->IDR & (0x01 << Broche) == (0x01 << Broche))
				reading = 1;
			else
				reading = 0;
		}
		else {
			if (Port->ODR & (0x01 << Broche) == (0x01 << Broche))
				reading = 1;
			else
				reading = 0;
		}
		else
			if (Port->CRH & (0x3 << (Broche-8)*4) = 0x00) {
				if (Port->IDR & (0x01 << Broche) == (0x01 << Broche))
					reading = 1;
				else
					reading = 0;
		}
		else {
			if (Port->ODR & (0x01 << Broche) == (0x01 << Broche))
				reading = 1;
			else
				reading = 0;
		}
	return reading;		
}
