#include <stdint.h>

void PUT32 (uint32_t, uint32_t);
void PUT16 ( uint32_t, uint32_t);
void PUTGETSET (uint32_t, uint32_t);
void PUTGETCLR (uint32_t, uint32_t);
void PUTGETSETMASK (uint32_t, uint32_t, uint32_t);
uint32_t GET32 (uint32_t);
uint32_t GET16 (uint32_t);
void dummy (uint32_t);


#define RCC_BASE 0x40021000

#define RCC_APB2ENR (RCC_BASE+0x18)


#define GPIOB_BASE 0x40011000

#define GPIOB_CRL  (GPIOB_BASE+0x00)
#define GPIOB_CRH  (GPIOB_BASE+0x04)
#define GPIOB_IDR  (GPIOB_BASE+0x08)
#define GPIOB_ODR  (GPIOB_BASE+0x0C)
#define GPIOB_BSRR (GPIOB_BASE+0x10)
#define GPIOB_BRR  (GPIOB_BASE+0x14)
#define GPIOB_LCKR (GPIOB_BASE+0x18)

int notmain(void)
{
	uint32_t ra;

    PUTGETSET(RCC_APB2ENR, 1 << 4); 					// enable GPIOC
    PUTGETSETMASK(GPIOB_CRH, 0xF << 20, 0x1 << 20);

    while(1) {
        PUT32(GPIOB_BSRR,0x00002000);
        for (ra=0;ra<100000;ra++) {
        	dummy(ra);
        }
        PUT32(GPIOB_BSRR,0x20000000);
        for(ra=0;ra<100000;ra++) {
        	dummy(ra);
        }
        PUT32(GPIOB_BSRR,0x00002000);
        for(ra=0;ra<100000;ra++) {
        	dummy(ra);
        }
        PUT32(GPIOB_BSRR,0x20000000);
        for(ra=0;ra<100000;ra++) {
        	dummy(ra);
        }
        PUT32(GPIOB_BSRR,0x00002000);
        for(ra=0;ra<100000;ra++) {
        	dummy(ra);
        }
        PUT32(GPIOB_BSRR,0x20000000);
        for(ra=0;ra<400000;ra++) {
        	dummy(ra);
        }
    }
    return(0);
}
