#ifndef __NR_LIB_H
#define __NR_LIB_H

#include "stm32f10x.h"

#define SYSCLK_FREQ_72MHz			72000000
#define CYCLES_PER_MICROSECOND		72
#define SYSTICK_RELOAD_VAL			SYSCLK_FREQ_72MHz / 1000
#define STM32_DELAY_US_MULT			12 /* FIXME: value is incorrect. */

#define GPIO_CNF_INPUT_ANALOG		0
#define GPIO_CNF_INPUT_FLOATING		1
#define GPIO_CNF_INPUT_PULLUPDOWN	2

#define GPIO_CNF_OUTPUT_PUSHPULL	0
#define GPIO_CNF_OUTPUT_OPENDRAIN	1
#define GPIO_CNF_AFIO_PUSHPULL		2
#define GPIO_CNF_AFIO_OPENDRAIN		3

#define GPIO_MODE_INPUT				0
#define GPIO_MODE_OUTPUT10MHz		1
#define GPIO_MODE_OUTPUT2MHz		2
#define GPIO_MODE_OUTPUT50MHz		3

#define GPIOCONF(mode, cnf)			((cnf << 2) | (mode))
#define GPIOPINCONFL(pin, conf)		(conf << (pin * 4))
#define GPIOPINCONFH(pin, conf)		(conf << ((pin - 8) * 4))

#define CONFMASKL(pin)				((uint32_t)~(15 << (pin * 4)))
#define CONFMASKH(pin)				((uint32_t)~(15 << ((pin - 8) * 4)))

/**
 * @brief Delay the given number of microseconds.
 *
 * @param us Number of microseconds to delay.
 */
static inline void delay_us(uint32_t us) {
    us *= STM32_DELAY_US_MULT;

    /* fudge for function call overhead  */
    us--;
    asm volatile("   mov r0, %[us]          \n\t"
                 "1: subs r0, #1            \n\t"
                 "   bhi 1b                 \n\t"
                 :
                 : [us] "r" (us)
                 : "r0");
}

/**
 * Delay for at least the given number of milliseconds.
 *
 * Interrupts, etc. may cause the actual number of milliseconds to
 * exceed ms.  However, this function will return no less than ms
 * milliseconds from the time it is called.
 *
 * @param ms the number of milliseconds to delay.
 * @see delayMicroseconds()
 */
void delay_ms(uint32_t ms);


void SystemInit(void);

#endif





























