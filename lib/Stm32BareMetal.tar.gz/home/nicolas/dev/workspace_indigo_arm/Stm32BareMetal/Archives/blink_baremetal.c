/* main.c
** Simple program for Olimex STM32-H103 (STM32F103RB) to flash LED on PC12
**
*/

#include <stm32f10x.h>

void delay(void);

void main(void)
{
  // I/O port C clock enable
  RCC->APB2ENR = RCC_APB2ENR_IOPCEN;
  // Set PC_12 to output
  GPIOC->CRH &= ~(GPIO_CRH_MODE12 | GPIO_CRH_CNF12);
  GPIOC->CRH |= GPIO_CRH_MODE12;

  while(1)
  {
    GPIOC->BSRR = (1<<12);
    delay();
    GPIOC->BRR = (1<<12);
    delay();
  }
}

void delay(void)
{
  volatile unsigned int i;

  for (i = 0; i < 20000; i++)
    ;
}
