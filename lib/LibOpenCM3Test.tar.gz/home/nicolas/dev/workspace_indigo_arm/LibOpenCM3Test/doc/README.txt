Programmation du STM32F103C8T6 avec la cl� USB stlink-v2
========================================================

set WORKAREASIZE 0x10000

Brancher la cl� stlink-v2 connect�e la carte STM32F103C8T6.
Lancer 2 consoles

Sur la premi�re:
----------------
$ cd /home/nicolas/dev/arm/tools/bin
$ ./run_stm.sh

Sur la deuxi�me:
----------------
$ telnet 127.0.0.1 4444

> halt

# dump du firmware existant 64Kb
> dump_image stm32f103c8t6.bin 0x08000000 0x0ffff

> halt
> flash probe 0
> stm32f1x mass_erase 0
> flash erase_check 0
> flash write_bank 0 /home/nicolas/dev/workspace_indigo_arm/LibOpenCM3Test/build/test_ledpc13.bin 0
> reset run


flash write_image erase <fichier_hex> 0

reset

exit

$

-------

Liste des images (*.hex)

flash write_bank 0 /home/nicolas/dev/workspace_indigo_arm/LibOpenCM3Test/build/test_ledpc13.bin 0


Configuration Arduino uno en mode USB to serial:
================================================
Installer un jumper sur les broches 5-6 du connecteur ISCP de l'arduino uno. (pins cot� MCU 328p).
Mise en reset permanent de l'Arduino uno.

D�brancher la carte arduino uno.
Brancher la broche 1 (TX) sur la sortie de la carte d'essai (transmission).
Brancher la broche 0 (RX) sur l'entr�e de la carte d'essai (r�ception).
Brancher la broche GND au moins de la carte d'essai.
Brancher la carte arduino uno.

Lancer le programme de transmission sur le device /dev/ttyACM0 (9600,8,N,1)


http://www.sciencezero.org/index.php?title=STM32F103_Microcontroller

https://github.com/BuFran/hal/blob/master/include/hal/delay.h
https://learn.adafruit.com/dash-hacking-bare-metal-stm32-programming/programming


#define TEMP_RES              0x100 /* temperature resolution => 1/256�C = 0.0039�C */


void DS1820_GetTempString(int16_t tRaw_s16, char *strTemp_pc)
{
    int16_t	tPhyLow_s16;
    int8_t	tPhy_s8;
    
    /* convert from raw value (1/256�C resolution) to physical value */
    tPhy_s8 = (int8_t)(tRaw_s16/TEMP_RES);
    
    /* convert digits from raw value (1/256�C resolution) to physical value */
    /*tPhyLow_u16 = tInt_s16 % TEMP_RES;*/
    
    tPhyLow_s16 = tRaw_s16 & 0xFF;      /* this operation is the same as */
                                        /* but saves flash memory tInt_s16 % TEMP_RES */
    tPhyLow_s16 = tPhyLow_s16 * 100;
    
    tPhyLow_s16 = (uint16_t)tPhyLow_s16 / TEMP_RES;
    
    /* write physical temperature value to string */
    sprintf(strTemp_pc, "%02d.%02d", tPhy_s8, (int8_t)tPhyLow_s16);
}

En hexa:
Temperature = 14�C
Temperature = 1D�C

Temperature = 14�C
Temperature = 1D�C

