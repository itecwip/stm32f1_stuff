#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/flash.h>
#include <libopencm3/stm32/gpio.h>
#include <libopencm3/cm3/nvic.h>
#include <libopencm3/cm3/systick.h>

#include "userlib.h"

uint32_t temp32;

/* PC13 -> on board led */

static void gpio_setup(void)
{
	/* Enable GPIOC clock. */
	rcc_periph_clock_enable(RCC_GPIOC);

	/* Set GPIO16 (in GPIO port C) to 'output push-pull' for the LEDs. */
	gpio_set_mode(GPIOC, GPIO_MODE_OUTPUT_2_MHZ, GPIO_CNF_OUTPUT_PUSHPULL, GPIO13);
}


int main(void)
{
	rcc_clock_setup_in_hse_16mhz_out_72mhz();
	gpio_setup();
	systick_setup();

	// gpio_clear(GPIOB, GPIO7);	/* LED1 on */
	gpio_set(GPIOC, GPIO13);		/* LED2 off */

	for(;;) {
		delay_us(1000 * 125);
		gpio_toggle(GPIOC, GPIO13); /* LEDPC13 on/off */
	}
	return 0;
}
