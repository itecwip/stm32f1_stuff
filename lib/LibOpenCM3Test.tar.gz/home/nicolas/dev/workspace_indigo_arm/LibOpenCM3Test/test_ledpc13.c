#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/flash.h>
#include <libopencm3/stm32/gpio.h>
#include <libopencm3/cm3/nvic.h>
#include <libopencm3/cm3/systick.h>
#include <libopencm3/stm32/usart.h>

#include "userlib.h"
#include "tm_stm32_onewire.h"
#include "tm_stm32_ds18b20.h"


static char			str_data[CVT_BUFF_LEN];

static void print(char *str) {
	while(*str) {
		usart_putchar_nonblocking(*str++);
	}
	usart_flush();
}


static void clock_setup(void)
{
	rcc_clock_setup_in_hse_8mhz_out_72mhz();

	/* Enable GPIOA clock (for OneWire). */
	rcc_periph_clock_enable(RCC_GPIOA);
}


int main(void)
{
	clock_setup();
	systick_setup();
	usart_setup();

	uint16_t 		temps = 0;
	uint8_t 		devices;
	uint8_t			count;
	uint8_t			device[2][8];
	TM_OneWire_t	OneWire1;		// OneWire working structure
	int				res;

	print("start\r\n");

	// Initialize OneWire on pin PC4
	TM_OneWire_Init(&OneWire1, GPIOA, GPIO0);

	do {
		/* Check for any device on 1-wire */
		devices = TM_OneWire_First(&OneWire1);
		count = 0;
		while (devices) {
			/* Increase count variable */
			count++;

			/* Get full 8-bytes rom address */
			TM_OneWire_GetFullROM(&OneWire1, device[count - 1]);

			/* Check for new device */
			devices = TM_OneWire_Next(&OneWire1);
		}

		/* If any devices on 1-wire */
		if (count > 0) {
//			print("Devices found on 1-wire: ");
//			nr_convert2dec(count, str_data); print(str_data); print("\n");

			/* Display 64bit rom code */
			for (uint8_t i = 0; i < count; i++) {
//				nr_convertdata2hex(device[i], str_data);
//				print(str_data); print("\n");

				if (TM_DS18B20_Is(device[i])) {
					// This is a DS18B20
					TM_DS18B20_SetResolution(&OneWire1, device[i], TM_DS18B20_Resolution_9bits);
					TM_DS18B20_Start(&OneWire1,device[i]);

					// Wait conversion
					while(!TM_DS18B20_AllDone(&OneWire1))
						;
					res = TM_DS18B20_Read(&OneWire1, device[i], &temps);
					if (res == -1) {
						print("CRC error !");
					} else if (res == 0) {
						print("Conversion not finished !");
					} else {
						// OK
						nr_convert2hex((uint32_t)temps, str_data);
						print("Temperature = ");
						print(str_data);
					}
					print("�C\n");
				}

			}
		} else {
			/* Nothing on OneWire */
			print("No devices on OneWire.\n\n");
		}
//		print("end\r\n");
		delay(500);
	} while (1);

	return 0;
}

////////////////////////////////////////////////////////
// Temperatursensor einstellen
// ROM Code: 0x10 0x12 0x08 0xd9 0x02 0x08 0x00 0x5b
////////////////////////////////////////////////////////

//uint8_t Init_DS18B20()
//{
//
//}

