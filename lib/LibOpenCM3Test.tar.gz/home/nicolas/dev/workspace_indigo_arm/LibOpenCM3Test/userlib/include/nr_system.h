#ifndef NR_SYSTEM_H
#define NR_SYSTEM_H

#include <stdint.h>

#include "userconf.h"

#if (USERLIB_USE_SYS == YES)

#define STM32_DELAY_US_MULT     12

void		systick_setup(void);
void		delay(uint16_t ms);
uint32_t	micros(void);
uint32_t	millis(void);

static inline void delay_us(uint32_t us)
{
    us *= STM32_DELAY_US_MULT;

    /* fudge for function call overhead  */
    us--;
    __asm volatile(
    		"   mov r0, %[us]          \n\t"
    		"1: subs r0, #1            \n\t"
    		"   bhi 1b                 \n\t"
        :
    : [us] "r" (us)
        : "r0");
}



#endif /* USERLIB_USE_SYS == YES */
#endif // NR_SYSTEM_H
