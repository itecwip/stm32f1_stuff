#include <libopencm3/cm3/nvic.h>
#include <libopencm3/cm3/systick.h>

#include "nr_system.h"

uint32_t runMillis = 0;

/* TIMING */
#define CYCLES_PER_MICROSECOND  72
#define SYSTICK_RELOAD_VAL      71999 /* takes a cycle to reload */
#define US_PER_MS               1000


void systick_setup(void)
{
	/* 72MHz / 8 => 9000000 counts per second */
	systick_set_clocksource(STK_CSR_CLKSOURCE_AHB_DIV8);

	/* 9000000/9000 = 1000 overflows per second - every 1ms one interrupt */
	/* SysTick interrupt every N clock pulses: set reload to N-1 */
	systick_set_reload(8999);

	systick_interrupt_enable();

	/* Start counting. */
	systick_counter_enable();
	runMillis = 0;
}

void sys_tick_handler(void)
{
	runMillis++;
}

uint32_t millis(void)
{
    return runMillis;
}

uint32_t micros(void)
{
    volatile uint32_t *SYSTICK_CNT = (uint32_t *)0xE000E018;
    uint32_t cycle_cnt;
    uint32_t ms;
    uint32_t res;

    do {
        ms = millis();
        cycle_cnt = *SYSTICK_CNT;
    } while (ms != millis());

    res = (ms * US_PER_MS) + (SYSTICK_RELOAD_VAL + 1 - cycle_cnt) / CYCLES_PER_MICROSECOND;

    return res;
}

void delay(uint16_t ms)
{
    uint32_t i;
    for (i = 0; i < ms; i++) {
        delay_us(1000);
    }
}

