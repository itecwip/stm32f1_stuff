
#include "nr_conversion.h"

void nr_convertdata(uint32_t num, uint32_t base, char *outBuff) {
	char	data[CVT_DATA_LEN];
	char	*str = &data[sizeof(data) -1];

	*str = '\0';
	do {
		uint32_t	m = num;

		num /= base;
		char	c = m - base * num;
		*--str = c < 10 ? c + '0' : c + 'A' - 10;

	} while(num);
	while(*str) {
		*outBuff++ = *str++;
	}
	*outBuff = '\0';
}

void nr_convertdata2hex(const uint8_t buff[8], char *outBuff) {
	for(uint8_t i = 0; i < 8; i++) {
		uint8_t	m1 = buff[i] / 16;
		uint8_t	m2 = buff[i] - 16 * m1;

		*outBuff++ = m1 < 10 ? m1 + '0' : m1 + 'A' - 10;
		*outBuff++ = m2 < 10 ? m2 + '0' : m2 + 'A' - 10;
	}
	*outBuff = '\0';
}
