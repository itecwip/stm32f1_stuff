#ifndef UART_H
#define UART_H

#include <stdint.h>

#include "userconf.h"

#if (USERLIB_USE_USART == YES)

/* which USART to use */
#define USART			USART1
#define USART_IRQ		NVIC_USART1_IRQ
#define USART_PORT		GPIOA
#define USART_PIN_TX	GPIO_USART1_TX
#define USART_PIN_RX	GPIO_USART1_RX

#define USART_RCC_GPIO	RCC_GPIOA
#define USART_RCC_AFIO	RCC_AFIO
#define USART_RCC_USART	RCC_USART1

	/* Enable clocks for GPIO port A (for GPIO_USART1_TX) and USART1. */
//	rcc_periph_clock_enable();
//	rcc_periph_clock_enable();
//	rcc_periph_clock_enable();


/* serial baudrate, in bits per second (with 8N1 8 bits, no parity bit, 1 stop bit settings) */
#define BAUD			9600

/* RX and TX buffer sizes */
#define USART_BUFFER	128

/* show how much received is available */
extern volatile uint8_t	rx_used;

/* setup USART port */
void usart_setup(void);

/* put character on USART (blocking) */
void usart_putchar_blocking(char c);

/* ensure all data has been transmitted (blocking) */
void usart_flush(void);

/* get character from USART (blocking) */
char usart_getchar(void);

/* put character on USART (non-blocking until buffer is full) */
void usart_putchar_nonblocking(char c);

#endif /* USERLIB_USE_USART == YES */
#endif
