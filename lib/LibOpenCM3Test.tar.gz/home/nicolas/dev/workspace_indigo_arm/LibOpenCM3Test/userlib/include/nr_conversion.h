#ifndef NR_CONVERSION_H
#define NR_CONVERSION_H

#include <stdint.h>

#include "userconf.h"

#if (USERLIB_USE_CONV == YES)

#define	CVT_DATA_LEN		11	// 10 chars + 1, used by outBuff in nr_convertdata()
#define	CVT_BUFF_LEN		17	// 16 chars + 1, used by outBuff in nr_convertdata2hex()

#define nr_convert2dec(num, outBuff)			nr_convertdata(num, 10, outBuff)
#define nr_convert2hex(num, outBuff)			nr_convertdata(num, 16, outBuff)

void		nr_convertdata(uint32_t num, uint32_t base, char *outBuff);
void		nr_convertdata2hex(const uint8_t buff[8], char *outBuff);
uint32_t	nr_strlen(char *str);


#endif /* USERLIB_USE_CONV == YES */
#endif // NR_CONVERSION_H
