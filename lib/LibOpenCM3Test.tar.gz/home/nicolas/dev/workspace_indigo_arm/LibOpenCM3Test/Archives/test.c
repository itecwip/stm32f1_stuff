void Systick_Init(void)
{
	if (SysTick_Config (SystemCoreClock / 1000)) //1ms per interrupt
		while (1);

	//set systick interrupt priority
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);    //4 bits for preemp priority 0 bit for sub priority
	NVIC_SetPriority(SysTick_IRQn, 0);//i want to make sure systick has highest priority amount all other interrupts

	Millis = 0;//reset Millis
}

uint32_t micros(void)
{
	Micros = Millis*1000 + 1000 – SysTick->VAL/72;
	// = Millis*1000+(SystemCoreClock/1000-SysTick->VAL)/72;
	return Micros;
}

uint32_t millis(void)
{
	return Millis;
}

void delay_ms(uint32_t nTime)
{
	uint32_t curTime = Millis;
	while((nTime-(Millis-curTime)) > 0);
}

void delay_us(uint32_t nTime)
{
	uint32_t curTime = Micros;
	while((nTime-(Micros-curTime)) > 0);
}


void SysTick_Handler(void) {
	Millis++;
}



#define STM32_DELAY_US_MULT		12		// 72MHz

/**
 * @brief Delay the given number of microseconds.
 *
 * @param us Number of microseconds to delay.
 */
static inline void delay_us(uint32 us) {
    us *= STM32_DELAY_US_MULT;

    /* fudge for function call overhead  */
    us--;
    asm volatile("   mov r0, %[us]          \n\t"
                 "1: subs r0, #1            \n\t"
                 "   bhi 1b                 \n\t"
                 :
                 : [us] "r" (us)
                 : "r0");
}

