#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/flash.h>
#include <libopencm3/stm32/gpio.h>
#include <libopencm3/cm3/nvic.h>
#include <libopencm3/cm3/systick.h>
#include <libopencm3/stm32/usart.h>

#include "userlib.h"

uint32_t temp32;

static char *hello = "hello\r\n";

static void clock_setup(void)
{
	rcc_clock_setup_in_hse_8mhz_out_72mhz();

	/* Enable GPIOA clock (for LED GPIO). */
	rcc_periph_clock_enable(RCC_GPIOC);
}

/* PC13 -> on board led */
static void gpio_setup(void)
{
	/* Set GPIO13 (in GPIO port C) to 'output push-pull' for the LED. */
	gpio_set_mode(GPIOC, GPIO_MODE_OUTPUT_2_MHZ, GPIO_CNF_OUTPUT_PUSHPULL, GPIO13);
}

int main(void)
{
	clock_setup();
	gpio_setup();
	systick_setup();
	usart_setup();

	// gpio_clear(GPIOB, GPIO7);	/* LED1 on */
	gpio_set(GPIOC, GPIO13);		/* LED2 off */

	for(;;) {
		delay_us(1000 * 500);
		gpio_toggle(GPIOC, GPIO13); /* LEDPC13 on/off */
		for(uint16_t n = 0; n < 7; n++) {
			usart_putchar_nonblocking(hello[n]);
		}
		while (rx_used) { // echo every received character
			usart_putchar_nonblocking(usart_getchar());
		}
	}
	return 0;
}
