var structtcb =
[
    [ "clockId", "structtcb.html#a419ca43cd619bee2e2fe3799adc8524c", null ],
    [ "eventQueue", "structtcb.html#a96e6ab9342c4a3c8ba4e2e9ed5b249be", null ],
    [ "internal_state", "structtcb.html#a8d2bbc009a66a7feb4304029e727ab56", null ],
    [ "msgQ", "structtcb.html#aa009515f932ab3d785f3eea541ee6b74", null ],
    [ "prio", "structtcb.html#acc0b27a6740f03639727be452f1e6b83", null ],
    [ "savedState", "structtcb.html#abfac7ca3b434b2eca39dbbc98997400e", null ],
    [ "semaphore", "structtcb.html#a3274c5c0859519c77745aee82e85c100", null ],
    [ "state", "structtcb.html#a84a8b308652d9493d14d5626cf75be92", null ],
    [ "taskproc", "structtcb.html#a96151276cc01348b4bb61336156a14d9", null ],
    [ "tid", "structtcb.html#a6f1dddf458f4e57fe3444309a958c73a", null ],
    [ "time", "structtcb.html#a93658cf9f03a3303cdb292e655c657e7", null ],
    [ "waitSingleEvent", "structtcb.html#afc6b3432b0eb3a76a5ce12d44e07482b", null ]
];