var cocoos_8h =
[
    [ "N_TOTAL_EVENTS", "cocoos_8h.html#aa18e0a77a01fef31ceaed94bea37afc6", null ],
    [ "N_TOTAL_SEMAPHORES", "cocoos_8h.html#aea1ff95d4d4e2a29f9697767f9a7b7df", null ],
    [ "NO_EVENT", "cocoos_8h.html#ab0f30b9957476899f0b8c7cb24f1cb4d", null ],
    [ "NO_QUEUE", "cocoos_8h.html#a50cf9cca4308d71b79d519d3234b3686", null ],
    [ "NO_SEM", "cocoos_8h.html#aaad932e462f246be28a651ec9b54f28b", null ],
    [ "NO_TID", "cocoos_8h.html#a80e779ac56d7d6c621a04873404b7249", null ],
    [ "OS_BEGIN", "cocoos_8h.html#a5898d5d7b19d566133755761f19496b1", null ],
    [ "OS_END", "cocoos_8h.html#a3e49e983b71f143cd8dc4e20742d1837", null ],
    [ "OS_SCHEDULE", "cocoos_8h.html#adb25868f2c1a3310aa91813de1d0cc31", null ],
    [ "OS_WAIT_TICKS", "cocoos_8h.html#af92a8ebffe0b32bfae91a9522acae682", null ],
    [ "os_running", "cocoos_8h.html#a943c88e42849b98b803f707d134baf79", null ],
    [ "last_running_task", "cocoos_8h.html#ac70e02976aa8431691b8fcba2ecb779d", null ],
    [ "running", "cocoos_8h.html#af77f8244799e85284b8b438289f5f689", null ],
    [ "running_tid", "cocoos_8h.html#a6857a184b9ad06cadd24899296af802a", null ]
];