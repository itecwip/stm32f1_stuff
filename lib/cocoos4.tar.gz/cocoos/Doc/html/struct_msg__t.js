var struct_msg__t =
[
    [ "delay", "struct_msg__t.html#adc4674f6ea53803d98fa2ec36759e77d", null ],
    [ "reload", "struct_msg__t.html#a93d00ff65cb704b727ac21435a9de782", null ],
    [ "reserved", "struct_msg__t.html#acb7bc06bed6f6408d719334fc41698c7", null ],
    [ "signal", "struct_msg__t.html#a7c1b70b404e83272e560887ddd8daf14", null ]
];