var os__event_8h =
[
    [ "EventQueue_t", "struct_event_queue__t.html", "struct_event_queue__t" ],
    [ "EVENT_OFS1", "os__event_8h.html#ae7036af54ecb6ae5b395a2a75b4e481b", null ],
    [ "EVENT_OFS2", "os__event_8h.html#ad04f8afd0b369899d82cf9148ac5ad34", null ],
    [ "EVENT_OFS3", "os__event_8h.html#a6aaecba285bcb06e6d2b2c91ab6c77c3", null ],
    [ "EVENT_QUEUE_SIZE", "os__event_8h.html#a3d16e5de491dfd7c361575b398679dd3", null ],
    [ "OS_INT_SIGNAL_EVENT", "os__event_8h.html#aa12c14b882481d0ced4b57d59a2dfde3", null ],
    [ "OS_SIGNAL_EVENT", "os__event_8h.html#af2f72c6e61490dd6bd78b14d1caf8886", null ],
    [ "OS_WAIT_MULTIPLE_EVENTS", "os__event_8h.html#ace1eefebee78331da1e9d97348709a35", null ],
    [ "OS_WAIT_SINGLE_EVENT", "os__event_8h.html#aee00eafa1b9015474edbc9a61b4db7e7", null ],
    [ "Evt_t", "os__event_8h.html#a14c2ea629ecea186a157b1ea3f9e9b5f", null ],
    [ "os_event_set_signaling_tid", "os__event_8h.html#a80983f2fab1a01a7dd6dd4bf0c44ba8d", null ],
    [ "os_signal_event", "os__event_8h.html#a17d4f782e35414af9e80c3c38d6eb76a", null ],
    [ "os_wait_event", "os__event_8h.html#a5241d71ab622ea4c944661e6f2f0b905", null ],
    [ "os_wait_multiple", "os__event_8h.html#a64b465c9031c95e48d6ac44c531d224c", null ]
];