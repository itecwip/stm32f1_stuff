var os__defines_8h =
[
    [ "ISR_TID", "os__defines_8h.html#ab3e9af0cb21805c998083b8ba37388a1", null ],
    [ "N_EVENTS", "os__defines_8h.html#ad57385a7bbcf00dd1ac27baa3de0b0f8", null ],
    [ "N_QUEUES", "os__defines_8h.html#abf72069a348a23137b90a8832f28750b", null ],
    [ "N_SEMAPHORES", "os__defines_8h.html#a97eb7e3111d7b8b670a1d13c00ac4d13", null ],
    [ "N_TASKS", "os__defines_8h.html#ab1a5b1011baa69070c3fc1b46b8b21d1", null ],
    [ "NO_MSG_ID", "os__defines_8h.html#af958a962b84f2d67674c0ecd9385e840", null ],
    [ "ROUND_ROBIN", "os__defines_8h.html#ab8315d87b0e79533609387c90acce4b7", null ],
    [ "Mem_t", "os__defines_8h.html#ab35226e3127a5daac6fd83dc099fbe75", null ]
];