var searchData=
[
  ['round_5frobin',['ROUND_ROBIN',['../os__defines_8h.html#ab8315d87b0e79533609387c90acce4b7',1,'os_defines.h']]]
];
