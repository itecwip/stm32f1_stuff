var searchData=
[
  ['event_5fcreate',['event_create',['../os__appl_a_p_i_8h.html#a04ba027b0848884aa6a2f5a346444be3',1,'os_event.c']]],
  ['event_5fisr_5fsignal',['event_ISR_signal',['../os__appl_a_p_i_8h.html#a90cd2126d49864ddb72738c12a01b34e',1,'os_applAPI.h']]],
  ['event_5fsignal',['event_signal',['../os__appl_a_p_i_8h.html#a194e9ed0f676ffc46a782754b58a0475',1,'os_applAPI.h']]],
  ['event_5fsignaling_5ftaskid_5fget',['event_signaling_taskId_get',['../os__appl_a_p_i_8h.html#ae28468ad6bb58df9d34ebd5bd3daa548',1,'os_event.c']]],
  ['event_5ft',['Event_t',['../struct_event__t.html',1,'']]],
  ['event_5fwait',['event_wait',['../os__appl_a_p_i_8h.html#a576b2326d068ab852846ee612c7b954c',1,'os_applAPI.h']]],
  ['event_5fwait_5fmultiple',['event_wait_multiple',['../os__appl_a_p_i_8h.html#a148bf0f2ab640ccf1cf29229d61defb6',1,'os_applAPI.h']]],
  ['event_5fwait_5ftimeout',['event_wait_timeout',['../os__appl_a_p_i_8h.html#adf6bffac3935c670ced14cf963fb0427',1,'os_applAPI.h']]]
];
