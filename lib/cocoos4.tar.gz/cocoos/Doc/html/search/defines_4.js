var searchData=
[
  ['sem_5fisr_5fsignal',['sem_ISR_signal',['../os__appl_a_p_i_8h.html#a429115c0709c08ce7459ff7e59cc8e36',1,'os_applAPI.h']]],
  ['sem_5fsignal',['sem_signal',['../os__appl_a_p_i_8h.html#aa5011c236fb03784283e6476e9ae5adb',1,'os_applAPI.h']]],
  ['sem_5fwait',['sem_wait',['../os__appl_a_p_i_8h.html#ab14d890b777d3b2a9e4c83a3ec15dd31',1,'os_applAPI.h']]]
];
