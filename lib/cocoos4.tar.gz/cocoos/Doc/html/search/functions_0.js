var searchData=
[
  ['event_5fcreate',['event_create',['../os__appl_a_p_i_8h.html#a04ba027b0848884aa6a2f5a346444be3',1,'os_event.c']]],
  ['event_5fsignaling_5ftaskid_5fget',['event_signaling_taskId_get',['../os__appl_a_p_i_8h.html#ae28468ad6bb58df9d34ebd5bd3daa548',1,'os_event.c']]]
];
