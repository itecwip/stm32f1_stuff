var searchData=
[
  ['task_5fcreate',['task_create',['../os__appl_a_p_i_8h.html#adb53dc7146d0e27f8ac2675f62dd6124',1,'os_task.c']]],
  ['task_5fid_5fget',['task_id_get',['../os__appl_a_p_i_8h.html#ab9e114be01c136878fc271be2a9c45cf',1,'os_task.c']]],
  ['task_5fkill',['task_kill',['../os__appl_a_p_i_8h.html#a36df952f331631590dc3a982e0e8a2d4',1,'os_task.c']]],
  ['task_5fstate_5fget',['task_state_get',['../os__appl_a_p_i_8h.html#a5587eb98c16ed4dd2adaa8ae2f3bb1e1',1,'os_task.c']]]
];
