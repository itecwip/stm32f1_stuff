var searchData=
[
  ['os_5fapplapi_2eh',['os_applAPI.h',['../os__appl_a_p_i_8h.html',1,'']]],
  ['os_5fcbksleep',['os_cbkSleep',['../os__appl_a_p_i_8h.html#a6723f9f2646d57c8a5e9bbd7dbc5279c',1,'os_cbk.c']]],
  ['os_5fdefines_2eh',['os_defines.h',['../os__defines_8h.html',1,'']]],
  ['os_5finit',['os_init',['../os__appl_a_p_i_8h.html#a6cc2e63d83267ff5059bf0a76b302a09',1,'os_kernel.c']]],
  ['os_5fstart',['os_start',['../os__appl_a_p_i_8h.html#a19c7111cf2121a69331d99dabe3e9df0',1,'os_kernel.c']]],
  ['os_5fsub_5fntick',['os_sub_nTick',['../os__appl_a_p_i_8h.html#a2025fabb507973af46a65be92eca1dd8',1,'os_kernel.c']]],
  ['os_5fsub_5ftick',['os_sub_tick',['../os__appl_a_p_i_8h.html#ac48c31882821ef8c2acef85235ee3d13',1,'os_kernel.c']]],
  ['os_5ftick',['os_tick',['../os__appl_a_p_i_8h.html#a1d7bc0554f6b515785211dd2c3f2d3d9',1,'os_kernel.c']]],
  ['osmsgq_5ft',['OSMsgQ_t',['../struct_o_s_msg_q__t.html',1,'']]]
];
