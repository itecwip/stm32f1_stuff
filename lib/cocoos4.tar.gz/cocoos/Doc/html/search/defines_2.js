var searchData=
[
  ['n_5fevents',['N_EVENTS',['../os__defines_8h.html#ad57385a7bbcf00dd1ac27baa3de0b0f8',1,'os_defines.h']]],
  ['n_5fqueues',['N_QUEUES',['../os__defines_8h.html#abf72069a348a23137b90a8832f28750b',1,'os_defines.h']]],
  ['n_5fsemaphores',['N_SEMAPHORES',['../os__defines_8h.html#a97eb7e3111d7b8b670a1d13c00ac4d13',1,'os_defines.h']]],
  ['n_5ftasks',['N_TASKS',['../os__defines_8h.html#ab1a5b1011baa69070c3fc1b46b8b21d1',1,'os_defines.h']]]
];
