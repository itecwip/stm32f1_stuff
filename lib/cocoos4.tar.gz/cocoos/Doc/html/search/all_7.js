var searchData=
[
  ['task_5fclose',['task_close',['../os__appl_a_p_i_8h.html#a7912af19af4a033fd9caf27879614945',1,'os_applAPI.h']]],
  ['task_5fcreate',['task_create',['../os__appl_a_p_i_8h.html#adb53dc7146d0e27f8ac2675f62dd6124',1,'os_task.c']]],
  ['task_5fid_5fget',['task_id_get',['../os__appl_a_p_i_8h.html#ab9e114be01c136878fc271be2a9c45cf',1,'os_task.c']]],
  ['task_5fkill',['task_kill',['../os__appl_a_p_i_8h.html#a36df952f331631590dc3a982e0e8a2d4',1,'os_task.c']]],
  ['task_5fopen',['task_open',['../os__appl_a_p_i_8h.html#ac19d6a48c1cb673360ae220aaf2a9d53',1,'os_applAPI.h']]],
  ['task_5fresume',['task_resume',['../os__appl_a_p_i_8h.html#ad6fc437b07612c85f0857e5f96b61fd0',1,'os_applAPI.h']]],
  ['task_5fstate_5fget',['task_state_get',['../os__appl_a_p_i_8h.html#a5587eb98c16ed4dd2adaa8ae2f3bb1e1',1,'os_task.c']]],
  ['task_5fsuspend',['task_suspend',['../os__appl_a_p_i_8h.html#a777527d4d0896af65a49a662fd1dff3f',1,'os_applAPI.h']]],
  ['task_5fwait',['task_wait',['../os__appl_a_p_i_8h.html#ad8232a672a6d4f3a4532bea410a0b1ef',1,'os_applAPI.h']]],
  ['task_5fwait_5fid',['task_wait_id',['../os__appl_a_p_i_8h.html#aade8755cf226e97b98eff894310f4257',1,'os_applAPI.h']]],
  ['tcb',['tcb',['../structtcb.html',1,'']]]
];
