var searchData=
[
  ['msg_5fpost',['msg_post',['../os__appl_a_p_i_8h.html#a017f7852a4fe5b619c58a9adf3d57bd7',1,'os_applAPI.h']]],
  ['msg_5fpost_5fasync',['msg_post_async',['../os__appl_a_p_i_8h.html#a508ce7180baed355bcf28f22ce23bf4e',1,'os_applAPI.h']]],
  ['msg_5fpost_5fevery',['msg_post_every',['../os__appl_a_p_i_8h.html#a1d4ff9caf0714728a46973fe7ef76868',1,'os_applAPI.h']]],
  ['msg_5fpost_5fin',['msg_post_in',['../os__appl_a_p_i_8h.html#abaae70bdc9e52397b8cb61698d850cda',1,'os_applAPI.h']]],
  ['msg_5freceive',['msg_receive',['../os__appl_a_p_i_8h.html#ac09ba62464c1027ee133b7a6878bfa83',1,'os_applAPI.h']]],
  ['msg_5freceive_5fasync',['msg_receive_async',['../os__appl_a_p_i_8h.html#ab47cae225480abc384877006e02b9ff7',1,'os_applAPI.h']]]
];
