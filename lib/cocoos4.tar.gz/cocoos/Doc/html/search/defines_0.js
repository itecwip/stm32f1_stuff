var searchData=
[
  ['event_5fisr_5fsignal',['event_ISR_signal',['../os__appl_a_p_i_8h.html#a90cd2126d49864ddb72738c12a01b34e',1,'os_applAPI.h']]],
  ['event_5fsignal',['event_signal',['../os__appl_a_p_i_8h.html#a194e9ed0f676ffc46a782754b58a0475',1,'os_applAPI.h']]],
  ['event_5fwait',['event_wait',['../os__appl_a_p_i_8h.html#a576b2326d068ab852846ee612c7b954c',1,'os_applAPI.h']]],
  ['event_5fwait_5fmultiple',['event_wait_multiple',['../os__appl_a_p_i_8h.html#a148bf0f2ab640ccf1cf29229d61defb6',1,'os_applAPI.h']]],
  ['event_5fwait_5ftimeout',['event_wait_timeout',['../os__appl_a_p_i_8h.html#adf6bffac3935c670ced14cf963fb0427',1,'os_applAPI.h']]]
];
