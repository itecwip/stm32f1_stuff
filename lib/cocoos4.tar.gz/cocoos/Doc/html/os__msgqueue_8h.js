var os__msgqueue_8h =
[
    [ "Msg_t", "struct_msg__t.html", "struct_msg__t" ],
    [ "OS_MSG_Q_EVENT_WAIT", "os__msgqueue_8h.html#ae7e580e9b0689e57908922dc026ef5cf", null ],
    [ "OS_MSG_Q_POST", "os__msgqueue_8h.html#a7a845268a4d55c98c281306fc75fb443", null ],
    [ "OS_MSG_Q_RECEIVE", "os__msgqueue_8h.html#a4d27fcc1a33a76488b8edd52a3e103e7", null ],
    [ "MsgQ_t", "os__msgqueue_8h.html#ad266146fca0839f8d36a2704c8f2f186", null ],
    [ "MSG_QUEUE_UNDEF", "os__msgqueue_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba122eabcbefdd3850fbffbb13c18b65db", null ],
    [ "MSG_QUEUE_DEF", "os__msgqueue_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba4bea77a616f63ab457a13bfd83e351e3", null ],
    [ "MSG_QUEUE_EMPTY", "os__msgqueue_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba5a96a103463ab49ab205f256816f7e50", null ],
    [ "MSG_QUEUE_FULL", "os__msgqueue_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba30abac2cad6e03738704eb1b7d7ee945", null ],
    [ "MSG_QUEUE_RECEIVED", "os__msgqueue_8h.html#a06fc87d81c62e9abb8790b6e5713c55baad02169370f92a281c5212fb2ddc6e18", null ],
    [ "MSG_QUEUE_POSTED", "os__msgqueue_8h.html#a06fc87d81c62e9abb8790b6e5713c55bab1b3f2e6d899a5ad3dca3e01f205940e", null ],
    [ "os_msg_post", "os__msgqueue_8h.html#af6e34ddf4b607764fd758a695daacfe3", null ],
    [ "os_msg_receive", "os__msgqueue_8h.html#ad355c3842f0bce7a9c3e8b90dc1177c6", null ],
    [ "os_msgQ_create", "os__msgqueue_8h.html#aa6bd853202df0bea7b4afc7e8e91cf26", null ],
    [ "os_msgQ_event_get", "os__msgqueue_8h.html#aa82e3c1762f9dd8caa6f957544183d52", null ],
    [ "os_msgQ_find", "os__msgqueue_8h.html#ad07b7b6d3cb8038bf99e7dfca73bffc7", null ],
    [ "os_msgQ_sem_get", "os__msgqueue_8h.html#ae32e5240d90954bca68c6311a056dd7f", null ],
    [ "os_msgQ_tick", "os__msgqueue_8h.html#a6c6dd585336321ca24c169a94c352120", null ]
];