var struct_o_s_msg_q__t =
[
    [ "change", "struct_o_s_msg_q__t.html#afc10846deb8f5ac0df1215d8b3077e47", null ],
    [ "head", "struct_o_s_msg_q__t.html#a9794c0e61506b826b49b458708ae2489", null ],
    [ "messageSize", "struct_o_s_msg_q__t.html#aa1a1001750b7ef127a50e908c45a62c6", null ],
    [ "msgPool", "struct_o_s_msg_q__t.html#a2a3828d57180996d740989bad9576302", null ],
    [ "mutex", "struct_o_s_msg_q__t.html#ac607015cfefd2b5634306d0241d62b02", null ],
    [ "pad", "struct_o_s_msg_q__t.html#ac1a86b4f13c0cf801df27e12ce75f046", null ],
    [ "size", "struct_o_s_msg_q__t.html#ae5dc6ffcd9b7605c7787791e40cc6bb0", null ],
    [ "tail", "struct_o_s_msg_q__t.html#a8db7f977b77e4e4d588ef0d3e04ada16", null ],
    [ "taskproc", "struct_o_s_msg_q__t.html#a96151276cc01348b4bb61336156a14d9", null ]
];