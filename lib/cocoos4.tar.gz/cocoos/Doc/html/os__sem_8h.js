var os__sem_8h =
[
    [ "OS_SIGNAL_SEM", "os__sem_8h.html#a4c519d682085c34a6c37a5a335f6c129", null ],
    [ "OS_SIGNAL_SEM_NO_SCHEDULE", "os__sem_8h.html#aa368e5ece56889e4ce20b074c98e1338", null ],
    [ "OS_WAIT_SEM", "os__sem_8h.html#a0ee83ee933db08ae83a4464dc7e17043", null ],
    [ "OS_WAIT_SEM_NO_SCHEDULE", "os__sem_8h.html#a8ce2093356e1790936b6193bd8de948c", null ],
    [ "SEM_OFS1", "os__sem_8h.html#a90e1f4ae95267f5e70ee0ff6ba6190ac", null ],
    [ "SEM_OFS2", "os__sem_8h.html#afe47a281ed553e17c8f3a6b628560fe2", null ],
    [ "Sem_t", "os__sem_8h.html#ae0ba7bfcccedf54ee2c0fb25db67b50d", null ],
    [ "os_sem_decrement", "os__sem_8h.html#a2a5a498076ce8019d1ce960790042aa8", null ],
    [ "os_sem_increment", "os__sem_8h.html#ab8b7036412b48f02636b83609c949b1e", null ],
    [ "os_sem_larger_than_zero", "os__sem_8h.html#ab7f2b7d1e04eb48613c34ba4b0ea80f8", null ]
];