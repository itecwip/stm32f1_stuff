
/*
 * SYNC PULSE v 2.0
 * Produces a TTL and AUDIO pulse for synchronization tests
 *
 * by Javier Jaimovich
 *
 * based on blink(http://www.arduino.cc/en/Tutorial/Blink)
 * and playmelody (http://www.arduino.cc/en/Tutorial/PlayMelody)
 */

//Options
#include <Arduino.h>
#include "userlib.h"

#define noise 1                 // Option to enable add jitter to pause interval (1=ON, 0=OFF)
#define manual_interval 1       // Option to enable potentiometer to change pause interval (1=ON, 0=OFF)
#define debug 1                 // debugging option (needs serial connection)

//Pin assignment
#define AudioPin 5              // Audio Pin
#define switchPin 2             // Pin to switch pulse configuration (manual or periodic)
#define intervalPin 0           // Analog pin to change pulse interval
#define buttonPin 3             // Pin to connect button for manual trigger of pulse

//Constants and defaults
#define play_time 200           // Blink interval (ms)
#define tono 2272               // Tone interval in ms, 2272 = 440 Hz 
#define jitter 3                // Interval jitter +-range (ms)
#define intMax 10000            // maximum pause time for manual interval
#define intMin 100              // minimum pause time for manual interval
#define baudrate 9600           // baudrate for serial communication
#define button_state HIGH       // TTL state for push button (HIGH for push-to-break, LOW for push-to-make) 

//global variables
float pause_time = 2000;        // Set default pause interval (ms)
int ledPin[] = {8, 9, 10, 11, 12, 13};        // TTL pins for LED
boolean run = false;            // variable to start stop pulse

void setup()                    // run once, when the sketch starts
{
  int i;
  for (i = 0; i < 6; i = i + 1) {
    pinMode(ledPin[i], OUTPUT); // sets the digital pin as output
  }
  pinMode(switchPin, INPUT);    // sets on off pin
  pinMode(AudioPin, OUTPUT);    // sets Audio pin
  pinMode(buttonPin, INPUT);    // sets button pin
  digitalWrite(buttonPin,HIGH); // pull up
  randomSeed(analogRead(5));    // randomize random sequence by reading empty analog pin
  if (debug == 1) {
    Serial.begin(baudrate);
  }
}

void playTone() {
  unsigned long now = millis();
  unsigned long elapsed_time = 0;
  while (elapsed_time < play_time) {
    digitalWrite(AudioPin,HIGH);
    delayMicroseconds(tono / 2);
    // DOWN
    digitalWrite(AudioPin, LOW);
    delayMicroseconds(tono / 2);
    // Keep track of how long we pulsed
    elapsed_time = millis() - now;
  } 
}

void pulse() {
  int i;
  for (i = 0; i < 6; i = i + 1) {
    digitalWrite(ledPin[i], HIGH);   // sets the LED on
  }
  playTone();
  for (i = 0; i < 6; i = i + 1) {
    digitalWrite(ledPin[i], LOW);   // sets the LED off
  }

}

// function to check change run option
void check_button () {
  if (digitalRead(buttonPin) == button_state) {
    run = !run; // change run state
    if (debug == 1) {
      Serial.println(byte(run),BIN);
    }
    delay(500); // debounce
  }
}

// function to pause between pulses
void pause() {
  // local variables
  unsigned long now;
  float rand = 0;
  float elapsed_time = 0;
  //check for noise option
  switch (noise) {
  case 1:
    rand = random(-jitter*100,jitter*100)*0.01; //generate random jitter
    now = micros(); //use microsecond resolution for jitter
    break;
  case 0:
    now = millis();
    break;
  }
  while (elapsed_time < (pause_time+rand)) {
    // check for manual interval option
    if (manual_interval == 1) {
      pause_time = analogRead(intervalPin)*((intMax-intMin)/1024)+intMin;
    }
    // Keep track of how long we pulsed
    switch (noise) {
    case 1:
      elapsed_time = micros()*0.001 - now*0.001; //use microsecond resolution for jitter
      break;
    case 0:
      elapsed_time = millis() - now; 
      break;
    }
    check_button();
  }
  if (debug == 1) {
    Serial.println(elapsed_time); //print pause time
  }
}

void loop()                     // run over and over again
{
  switch (digitalRead(switchPin)) {
  case HIGH:
    if (run == true) {
      pulse();
      pause();
    }
    else {
      check_button();
    }
    break; 
  case LOW:
    if (digitalRead(buttonPin) == button_state) {
      pulse();
      delay(200); // debounce
      if (debug == 1) {
        Serial.println(8888);
      }
    }
    run = false; //forces run mode to always start OFF
    break;
  }
}
