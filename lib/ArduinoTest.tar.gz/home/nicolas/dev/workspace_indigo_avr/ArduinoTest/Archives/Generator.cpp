#include <Arduino.h>
#include "userlib.h"


// Arduino UNO DDS

#include <PWM.h>

int32_t frequency_9 = 20; //frequency (in Hz)


void setup()
{

InitTimersSafe();

SetPinFrequencySafe(9, frequency_9);

}

void loop()
{
// Pin 9
 int dutyC =512; // Duty Cycle 0 (0%) - 1023(100%)
 pwmWrite(9, dutyC / 4);
 delay(30);

 }


