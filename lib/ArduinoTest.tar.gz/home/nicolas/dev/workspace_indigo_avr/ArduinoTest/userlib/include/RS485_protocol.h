#ifndef _RS485_NB_H_
#define _RS485_NB_H_


#include "Arduino.h"
#include "userconf.h"

#if (USERLIB_USE_RS485 == TRUE) || defined(__DOXYGEN__)

typedef void (*WriteCallback)  (const byte what);    // send a byte to serial port
typedef int  (*AvailableCallback)  ();    // return number of bytes available
typedef int  (*ReadCallback)  ();    // read a byte from serial port

#ifdef __cplusplus
extern "C" {
#endif

void sendMsg (WriteCallback fSend, const byte * data, const byte length);

byte recvMsg (AvailableCallback fAvailable, ReadCallback fRead, 
              byte * data, const byte length, 
              unsigned long timeout = 500);

#ifdef __cplusplus
}
#endif

#endif /* USERLIB_USE_RS485 == TRUE */

#endif /* _RS485_NB_H_ */
