/**
 * @file    userconf.h
 * @brief   Userlib configuration header.
 * @details Userlib configuration file, this file allows to enable or disable the
 *          various device drivers from your application. You may also use
 *          this file in order to override the device drivers default settings.
 *
 * @addtogroup USER_CONF
 * @{
 */

#ifndef _USERCONF_H_
#define _USERCONF_H_

/**
 * @brief   Enables the RS485 subsystem.
 */
#if !defined(USERLIB_USE_RS485) || defined(__DOXYGEN__)
#define USERLIB_USE_RS485			FALSE
#endif

/**
 * @brief   Enables the RS485 non blocking subsystem.
 */
#if !defined(USERLIB_USE_RS485_NB) || defined(__DOXYGEN__)
#define USERLIB_USE_RS485_NB		FALSE
#endif

/**
 * @brief   Enables the Software Serial subsystem.
 */
#if !defined(USERLIB_USE_SFT_SER) || defined(__DOXYGEN__)
#define USERLIB_USE_SFT_SER 		FALSE
#endif

/**
 * @brief   Enables the EEPROM objects.
 */
#if !defined(USERLIB_USE_EEPROM) || defined(__DOXYGEN__)
#define USERLIB_USE_EEPROM			FALSE
#endif


/**
 * @brief   Enables the One wire subsystem.
 */
#if !defined(USERLIB_ONEWIRE) || defined(__DOXYGEN__)
#define USERLIB_ONEWIRE				TRUE
#endif

/**
 * @brief   Enables the Dallas DS18xx temperature One wire subsystem.
 * set USERLIB_ONEWIRE to TRUE
 */
#if !defined(USERLIB_OW_DS18) || defined(__DOXYGEN__)
#define USERLIB_OW_DS18				TRUE
#endif

#endif /* _USERCONF_H_ */

/** @} */
