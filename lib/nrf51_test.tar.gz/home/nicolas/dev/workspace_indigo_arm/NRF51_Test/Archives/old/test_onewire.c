/* BSPACM - nRF51 DS18B20 OneWire example
 *
 * Written in 2014 by Peter A. Bigot <http://pabigot.github.io/bspacm/>
 *
 * To the extent possible under law, the author(s) have dedicated all
 * copyright and related and neighboring rights to this software to
 * the public domain worldwide. This software is distributed without
 * any warranty.
 *
 * You should have received a copy of the CC0 Public Domain Dedication
 * along with this software. If not, see
 * <http://creativecommons.org/publicdomain/zero/1.0/>.
 */

#include <stdarg.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include "nrf.h"
#include "nrf_delay.h"

/*
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <bspacm/utility/led.h>
#include <bspacm/newlib/ioctl.h>
#include <bspacm/utility/misc.h>
#include <bspacm/utility/hires.h>
*/
#include <onewire.h>
#include "uart.h"


#define TX_PIN_NUMBER        (17)
#define RX_PIN_NUMBER        (19)
#define ONEWIRE_DQ_PIN		18
#define ONEWIRE_PWR_PIN		20


int main()
{
	uart_config(TX_PIN_NUMBER, RX_PIN_NUMBER);

	do {
  	uart_putstring((const uint8_t *)"STart onewire\r\n");
    sBSPACMonewireBus bus_config;
    hBSPACMonewireBus bus = hBSPACMonewireConfigureBus(&bus_config, ONEWIRE_DQ_PIN, ONEWIRE_PWR_PIN);

    sBSPACMonewireSerialNumber	serial;
    int16_t						t_xCel = -1;
    int							rc;
    char						start_msg[128];

    if (!iBSPACMonewireReset(bus)) {
    	uart_putstring((const uint8_t *)"No DS18B20 present\r\n");
      // printf("ERR: No DS18B20 present on P0.%u\n", ONEWIRE_DQ_PIN);
      break;
    }

    // static const char * const supply_type[] = { "parasitic", "external" };

    int external_power = iBSPACMonewireReadPowerSupply(bus);
    // printf("Power supply: %s\n", supply_type[external_power]);
    if (0 > external_power) {
    	uart_putstring((const uint8_t *)"ERROR: Device not present?\r\n");
      // printf("ERROR: Device not present?\n");
      break;
    }


    rc = iBSPACMonewireReadSerialNumber(bus, &serial);
    // printf("Serial got %d: ", rc);
    // vBSPACMconsoleDisplayOctets(serial.id, sizeof(serial.id));
    // putchar('\n');

    while (0 == iBSPACMonewireRequestTemperature(bus)) {
      if (external_power) {
        /* Wait for read to complete.  Conversion time can be as long as
         * 750 ms if 12-bit resolution is used (this resolution is the
         * default). Timing will be wrong unless interrupts are enabled
         * so uptime overflow events can be handled.  Sleep for 600ms,
         * then test at 10ms intervals until the result is ready. */
    	  nrf_delay_us(600);
        while (! iBSPACMonewireReadBit(bus)) {
        	nrf_delay_us(10);
        }
      } else {
        /* Output high on the parasitic power boost line for 750ms, to
         * power the conversion.  Then switch that signal back to
         * input so the data can flow over the same circuit. */
        vBSPACMonewireParasitePower(bus, true);
        nrf_delay_us(750);
        vBSPACMonewireParasitePower(bus, false);
      }
      rc = iBSPACMonewireReadTemperature(bus, &t_xCel);
      vBSPACMonewireShutdown(bus);
      sprintf(&start_msg[0], "Got %d xCel, %d dCel, %d d[degF], %d dK\n", t_xCel,
    		              BSPACM_ONEWIRE_xCel_TO_dCel(t_xCel), BSPACM_ONEWIRE_xCel_TO_ddegF(t_xCel), BSPACM_ONEWIRE_xCel_TO_dK(t_xCel));
      uart_putstring((const uint8_t *) &start_msg[0]);
//      printf("Got %d xCel, %d dCel, %d d[degF], %d dK\n", t_xCel,
//             BSPACM_ONEWIRE_xCel_TO_dCel(t_xCel), BSPACM_ONEWIRE_xCel_TO_ddegF(t_xCel), BSPACM_ONEWIRE_xCel_TO_dK(t_xCel));
      nrf_delay_us(1000);
    } // while

  } while(0);

  // fflush(stdout);
  // ioctl(1, BSPACM_IOCTL_FLUSH, O_WRONLY);
  // BSPACM_CORE_DEEP_SLEEP();
  return 0;
}
