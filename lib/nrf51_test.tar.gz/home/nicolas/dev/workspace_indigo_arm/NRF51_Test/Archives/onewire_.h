#ifndef __ONEWIRE_H
#define __ONEWIRE_H

#include <stdint.h>

typedef struct {
	volatile uint8_t		*port_out;
	const volatile uint8_t	*port_in;
	volatile uint8_t		*port_ren;
	volatile uint8_t		*port_dir;
	uint32_t				pin;
} onewire_t;

//########################################################################
/*
int		onewire_reset(onewire_t *ow);
void	onewire_write_bit(onewire_t *ow, int bit);
int		onewire_read_bit(onewire_t *ow);
void	onewire_write_byte(onewire_t *ow, uint8_t byte);
uint8_t	onewire_read_byte(onewire_t *ow);
void	onewire_line_low(onewire_t *ow);
void	onewire_line_high(onewire_t *ow);
void	onewire_line_release(onewire_t *ow);
*/
int		onewire_reset(uint32_t pin);
void	onewire_write_bit(uint32_t pin, int bit);
int		onewire_read_bit(uint32_t pin);
void	onewire_write_byte(uint32_t pin, uint8_t byte);
uint8_t	onewire_read_byte(uint32_t pin);
void	onewire_line_low(uint32_t pin);
void	onewire_line_high(uint32_t pin);
void	onewire_line_release(uint32_t pin);

#endif
