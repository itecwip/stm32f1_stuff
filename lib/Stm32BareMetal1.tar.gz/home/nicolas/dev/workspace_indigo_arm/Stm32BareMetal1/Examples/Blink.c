#include "nr_lib.h"

#include "delay.h"
#include "sys.h"


static void gpio_setup(void)
{
	/* Enable GPIOC clock. */
	RCC->APB2ENR = RCC_APB2ENR_IOPCEN;
	// Set PC_12 to output

	/* Set GPIO13 (in GPIO port C) to 'output push-pull'. */
	GPIOC->CRH &= ~(GPIO_CRH_MODE13 | GPIO_CRH_CNF13);
	GPIOC->CRH |= GPIO_CRH_MODE13;
}

int main(void)
{
	SystemInit(); 			 // SYSCLK_FREQ_72MHz
	delay_init(72);
	NVIC_Configuration();
	gpio_setup();

	while(1) {
		// GPIOC_BSRR = GPIO13;	// LED off - GPIO_ResetBits(GPIOC,GPIO_Pin_13);
		GPIOC->BSRR = (1<<13);
		delay_us(300 * 1000);
		// GPIOC_BRR = GPIO13;		// LED on - GPIO_SetBits(GPIOC,GPIO_Pin_13);
		GPIOC->BRR = (1<<13);
		delay_us(300 * 1000);
	}
}

