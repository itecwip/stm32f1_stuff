#include "nr_lib.h"
#include "delay.h"

static u8  fac_us = 0;
static u16 fac_ms = 0;

// from /MINISTM32/STM32F10x_FWLib/inc/misc.h
#define SysTick_CLKSource_HCLK_Div8    ((uint32_t)0xFFFFFFFB)

//SYSTICK 1/8
//SYSCLK:
void delay_init(uint8_t SYSCLK)
{
	SysTick->CTRL &= SysTick_CLKSource_HCLK_Div8;	// bit2 HCLK/8
	fac_us = SYSCLK / 8;
	fac_ms = (uint16_t)fac_us * 1000;
}								    

// SysTick->LOAD
// nms <= 0xffffff * 8 * 1000 / SYSCLK
// SYSCLK
// nms <= 1864
void delay_ms(uint16_t nms)
{	 		  	  
	uint32_t temp;

	SysTick->LOAD = (uint32_t)nms * fac_ms; // (SysTick->LOAD 24bit)
	SysTick->VAL = 0x00;
	SysTick->CTRL = 0x01;
	do {
		temp = SysTick->CTRL;
	} while(temp & 0x01 && !(temp & (1 << 16)));
	SysTick->CTRL = 0x00;
	SysTick->VAL = 0X00;
}


void delay_us(uint32_t nus)
{		
	uint32_t temp;

	SysTick->LOAD = nus * fac_us;
	SysTick->VAL = 0x00;
	SysTick->CTRL = 0x01;
	do {
		temp = SysTick->CTRL;
	} while(temp & 0x01 && !(temp & (1 << 16)));
	SysTick->CTRL = 0x00;
	SysTick->VAL = 0X00;
}



































