
#ifndef _main_h_
#define _main_h_

//#define F_CPU 1000000UL
#define F_CPU 1000000UL

#endif
