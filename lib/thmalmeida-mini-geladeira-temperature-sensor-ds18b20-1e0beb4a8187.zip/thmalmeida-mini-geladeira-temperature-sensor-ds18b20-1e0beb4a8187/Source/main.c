/*
   DS18x20 Demo-Programm
   
   V 0.7, 3/2005
	PetrKpy 6/2007 modified for LCD
   
   by Martin Thomas <eversmith@heizung-thomas.de>
   http://www.siwawi.arubi.uni-kl.de/avr-projects
    
   features:
   - DS18X20 and 1-Wire code is based on a sample from Peter 
     Dannegger
   - uses Peter Fleury's uart-library which is very portable 
     between AVRs, added some functions in the uart-lib
   - CRC-check based on code from Colin O'Flynn
   - access multiple sensors on multiple 1-Wire busses
   - samples how to address every sensor in the bus by ROM-code
   - independant of system-timers (more portable) but some
     (very short) delays used
   - avr-libc inttypes 
   - no central include-file, parts of the code can be used as
     "library"
   - verbose output (different levels configureable)
   - one-wire-bus can be changed at runtime if OW_ONE_BUS
     is not defined in onewire.h. There are still timing issues.
	 Tests done with ATmega16 3,68MHz XTAL OK, , 8MHz intRC OK, 
	 4MHz intRC OK, 2MHz intRC OK, 1,84MHz XTAL OK, 1MHz intRC 
	 failed in runtime-configureable OW-Bus. All frequencies do 
	 work in OW_ONE_BUS-Mode.
   - support-functions for DS18x20 internal EEPROM
*/

#include "main.h"

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <compat/deprecated.h>
#include <string.h>
#include <stdio.h>

#include <util/delay.h>

#include "onewire.h"
#include "ds18x20.h"

#include "lcd.h"

#define MAXSENSORS 5


// ---------- In header file ----------
#define KEY_UP         1
#define KEY_DN         2

// Pins
#define KEY_PINS       PINB

// Macros
#define KEY_DN_PRESS   (~(KEY_PINS) & (1<<KEY_DN))
#define KEY_UP_PRESS   (~(KEY_PINS) & (1<<KEY_UP))

uint8_t gSensorIDs[MAXSENSORS][OW_ROMCODE_SIZE];

char lcd_buffer[19];
//static volatile uint8_t minute=0;	//must be volatile because modified by interrupt handler

uint16_t minutes;
uint8_t tela=0;

uint8_t expire=0;
uint8_t value=0;

uint8_t var01=0;
int8_t var02;
int8_t var03;
int8_t var04;
uint8_t var05=0;
uint8_t var06=0;

int16_t Tmax=140;
int16_t Tmin=70;
int16_t temp[2];
int16_t p_Operacao;

uint8_t hour=0;
uint8_t min=0;
uint8_t sec=0;

uint8_t nSensors, i;
uint8_t subzero, cel, cel_frac_bits;

uint16_t timeON=0, timeOFF=0;

uint8_t flag=1;
uint16_t eficiencia;

typedef enum{
	INITIALIZING,
	WORKING,
	WAITING,
	STANDBY,
	SLEEPING,
	SETTINGS
}states1;

states1 estado1 = INITIALIZING;

typedef enum{
	MODE,
	POWER1,
	POWER2,
	AJUSTE,
	HORA
}states2;

states2 estado2 = MODE;
	

void initializing(void);
void working(void);
void process_machine_state(void);
void automatic_Mode(void);

void time_adjust(void);

int8_t read_keys(void)
{
	if(KEY_UP_PRESS)
	{
		expire = 1;
		_delay_ms(100);
		while(KEY_UP_PRESS);      // Wait for key to be released
		_delay_ms(100);
		return 1;
	}
	if(KEY_DN_PRESS)
	{
		expire = 1;
		_delay_ms(100);
		while(KEY_DN_PRESS);
		_delay_ms(100);
		return -1;
	}
	else return 0;
} 


uint8_t search_sensors(void)
{
	uint8_t i;
	uint8_t id[OW_ROMCODE_SIZE];
	uint8_t diff, nSensors;
	
	/* clear display and home cursor */
	lcd_clrscr();
	lcd_puts("Bus scanning ...\n");
	
	nSensors = 0;

	for( diff = OW_SEARCH_FIRST; diff != OW_LAST_DEVICE && nSensors < MAXSENSORS ; )
	{
		DS18X20_find_sensor( &diff, &id[0] );

		if( diff == OW_PRESENCE_ERR )
		{
			lcd_puts("No sensor found\n");
			break;
		}
	
		if( diff == OW_DATA_ERR )
		{
			lcd_puts("Bus error\n");
			break;
		}
	
		for (i=0;i<OW_ROMCODE_SIZE;i++)
			gSensorIDs[nSensors][i]=id[i];
	
		nSensors++;
	}
	
	_delay_ms(1000);
	return nSensors;
}

void lcd_put_temp(const uint8_t subzero, uint8_t cel, uint8_t cel_frac_bits)
{
	char symbl=223;
	
	/*
	uint8_t buffer[sizeof(int)*8+1];
	uint8_t i, j;
	
	lcd_putc((subzero)?'-':'+');
	sprintf(lcd_buffer,"%d",(int)cel);
	lcd_puts(lcd_buffer);
	lcd_puts(".");
	itoa((cel_frac_bits*DS18X20_FRACCONV),buffer,10);
	j=4-strlen(buffer);
	for (i=0;i<j;i++) lcd_puts("0");
	lcd_puts(buffer);
	sprintf(lcd_buffer,"%cC\n",symbl);
	lcd_puts(lcd_buffer);
	*/
	
	// "rounding"
	uint16_t decicelsius;
	
	lcd_putc((subzero)?'-':'+');
	decicelsius = DS18X20_temp_to_decicel(subzero, cel, cel_frac_bits);
	sprintf(lcd_buffer,"%d", (int)(decicelsius/10) );
	lcd_puts(lcd_buffer);
	lcd_puts(".");
	sprintf(lcd_buffer,"%d", (decicelsius%10)); // + '0')
	lcd_puts(lcd_buffer);
	sprintf(lcd_buffer,"%cC  ",symbl);
	lcd_puts(lcd_buffer);
	
}

SIGNAL(SIG_OUTPUT_COMPARE1A)
{
	sec++;
	expire++;
/*
	if(sec == 59)
	{
		sec = 0;
		if(min == 59)
		{
			min = 0;
			if(hour == 23)
				hour = 0;
			else
				hour++;
		}
		else
		{
			min++;
			minutes++;
		}
	}
	else
	{
		sec++;
		expire++;
	}
*/
}

int main( void )
{
	// Clear all interruptions
	cli();

/* Enable Clock Prescaler and select clk/1 - 8MHz */
//	CLKPR = 0x80;
//	CLKPR = 0x00;

	// Setting switch buttons as INPUT
	DDRB &= ~((1<<PD1) | (1<<PD2));

	// Setting driver port as OUTPUT
	DDRD |= (1<<PD7);

	// Edit ports by user
	#ifndef OW_ONE_BUS
	ow_set_bus(&PINB,&PORTB,&DDRB,PB0);
	#endif

	// TIMER0 8 bits - Fast PWM
	DDRD = (1 << 6);
	OCR0A = 25;
//	TIMSK0 = (1 << TOIE0);
//	TCCR0A |= (1 << COM0A1) | (1 << COM0A0) | (1<<WGM01) |(1 << WGM00); 
	TCCR0A = (3 << COM0A0)|(3 <<  WGM00);
	TCCR0B = (1 << CS00);

//	TCCR0A = 0b01000010;	//(1<<COM0A1) | (1<<COM0A0) | (1<<COM0B0) | (1<<COM0B1) | ~(1<<WGM01) | ~(1<<WGM00);
//	TCCR0B = 0b00000001;    //~(1<<FOC0A) | ~(1<<FOC0B) | ~(1<<WGM02)  | ~(1<<CS02) | (1<<CS01)  | (1<<CS00);
//	TIMSK0 = 0x06;		//(1<<OCIE0B) | (1<<OCIE0A) | ~(1<<TOIE0);
//	TIFR0  = 0x04;	// (1<<OCF0B) | (1<<OCF0A);

	// Configure timer 1 for CTC mode
	TCCR1B |= ((1 << WGM12)|(1 << CS10) | (1 << CS11)); // Start timer at Fcpu/64
	OCR1A = 15625; // Set CTC compare value to 1Hz at 1MHz AVR clock, with a prescaler of 64
	TIMSK1 |= (1 << OCIE1A); // Enable CTC interrupt
	sei(); // Enable global interrupts

//	timeOFF = eeprom_read_word((uint16_t*)0);
//	timeON  = eeprom_read_word((uint16_t*)4);

//	eficiencia = 100*timeON/(timeON+timeOFF);

	while(1)
		process_machine_state();

	return(0);
}

void process_machine_state(void){
	switch(estado1){

		case INITIALIZING:
			initializing();
			estado1 = WORKING;
			break;

		case WORKING:

			lcd_gotoxy(0,0);
			if(var01 == 0)
			{
				lcd_puts("  Modo  Automatico  \n");
				automatic_Mode();
			}
			else
				lcd_puts("    Modo  Manual    \n");

			working();

			if(tela == 0)
			{
				sprintf(lcd_buffer,"OFF=%2u ON=%2u",timeOFF,timeON);
				lcd_gotoxy(0,3);
				lcd_puts("                    ");
				lcd_gotoxy(0,3);
				lcd_puts(lcd_buffer);
			}
			if(tela == 1)
			{
				sprintf(lcd_buffer,"Tmax=%d.%d Tmin=%d.%d\n",(int)(Tmax/10),Tmax%10,(int)(Tmin/10),Tmin%10);
				lcd_gotoxy(0,3);
				lcd_puts("                    ");
				lcd_gotoxy(0,3);
				lcd_puts(lcd_buffer);
			}

			if(tela == 2)
			{
				lcd_gotoxy(0,3);
				lcd_puts("                    ");
				sprintf(lcd_buffer,"f= %2d%%", eficiencia);
				lcd_gotoxy(6,3);
				lcd_puts(lcd_buffer);
			}

			if(tela == 3)
			{
				lcd_gotoxy(0,3);
				sprintf(lcd_buffer,"Time= %d", minutes);
				lcd_puts("                    ");
				lcd_gotoxy(5,3);
				lcd_puts(lcd_buffer);
			}

			estado1 = WAITING;
			break;
			

		case WAITING:

			lcd_gotoxy(6,2);
			sprintf(lcd_buffer,"%2.2u:%2.2u:%2.2u", hour,min,sec);
			lcd_puts(lcd_buffer);

			if(expire >= 10)
			{
				estado1 = WORKING;
				expire = 0;
				if(tela==3)
					tela = 0;
				else
					tela++;
			}

			if(read_keys() == 1)
				estado1 = SETTINGS;

			if(var06 == 1)
			{
				if((hour == 23)||(hour < 7))
				{
					lcd_clrscr();
					estado1 = SLEEPING;
					OCR0A = 242;
					PORTD &= ~(1<<PD7);
					minutes = 0;
				}
			}

			time_adjust();

			break;

		case STANDBY:
			lcd_gotoxy(4,1);
			lcd_puts("StandBy Mode");

			lcd_gotoxy(6,3);
			sprintf(lcd_buffer,"%2.2u:%2.2u:%2.2u", hour,min,sec);

			lcd_puts(lcd_buffer);

			if(read_keys() == 1)
				estado1 = SETTINGS;

			time_adjust();

			break;

		case SLEEPING:
			lcd_gotoxy(3,0);
			lcd_puts("Sleeping  Mode");

			lcd_gotoxy(6,2);
			sprintf(lcd_buffer,"%2.2u:%2.2u:%2.2u", hour,min,sec);
			lcd_puts(lcd_buffer);

			if(read_keys() == 1)
			estado1 = SETTINGS;

			if((hour >= 7)&&(hour<23))
			{
				estado1 = WORKING;
				OCR0A = 40;
			}

			time_adjust();

			break;

		case SETTINGS:

			lcd_clrscr();

			while(expire < 10)
			{
				lcd_gotoxy(0,0);
				lcd_puts("Configuracao:\n");

				switch (estado2){
					case MODE:
						lcd_gotoxy(4,1);
						lcd_puts("-Temperatura\n");
						lcd_puts("Automatico\n");
						lcd_puts("Manual    \n");

						if(var01 == 0)
						{
							lcd_gotoxy(13,2);
							lcd_puts("X\n");
							lcd_gotoxy(13,3);
							lcd_puts(" \n");
						}
						else
						{
							lcd_gotoxy(13,2);
							lcd_puts(" \n");
							lcd_gotoxy(13,3);
							lcd_puts("X\n");
						}

						var02 = read_keys();
						if(var02 == -1)
						var01 = !var01;

						if(var02 == 1)
						{
							if(var01 == 1)
								estado2 = AJUSTE;
							else
								estado2 = POWER1;
						}
						break;

					case AJUSTE:
						lcd_gotoxy(4,1);
						lcd_puts("-Ajuste Manual\n");

						lcd_puts("Tmax= \n");
						lcd_puts("Tmin= \n");

						sprintf(lcd_buffer,"%4d",(int)(Tmax/10));
						lcd_gotoxy(6,2);
						lcd_puts(lcd_buffer);
						lcd_puts(".");
						sprintf(lcd_buffer,"%d", (Tmax%10));
						lcd_puts(lcd_buffer);

						sprintf(lcd_buffer,"%4d",(int)(Tmin/10));
						lcd_gotoxy(6,3);
						lcd_puts(lcd_buffer);
						lcd_puts(".");
						sprintf(lcd_buffer,"%d", (Tmin%10));
						lcd_puts(lcd_buffer);

						if(var04 == 0)
						{
							lcd_gotoxy(13,2);
							lcd_puts("X");
							lcd_gotoxy(13,3);
							lcd_puts(" ");
						}
						else
						{
							lcd_gotoxy(13,2);
							lcd_puts(" ");
							lcd_gotoxy(13,3);
							lcd_puts("X");
						}

						var02 = read_keys();

						if(var02 == 1)
						{
							if(var04 == 1)
							{
								var04 = !var04;
								estado2 = POWER1;
							}
							else
								var04 = !var04;
						}

						if(var02 == -1)
						{
							if(var04 == 0)
								Tmax=Tmax+10;
							else
								Tmin=Tmin+10;
						}

						if(Tmax >= 250)
							Tmax = 0;
						if(Tmin >= 250)
							Tmin = 0;
						break;

					case POWER1:
						lcd_gotoxy(4,1);
						lcd_puts("-Energia      \nNormal      \nStandby     \n");

						if(var03 == 0)
						{
							lcd_gotoxy(13,2);
							lcd_puts("X\n");
							lcd_gotoxy(13,3);
							lcd_puts(" \n");
							OCR0A = 40;

						}
						else
						{
							lcd_gotoxy(13,2);
							lcd_puts(" \n");
							lcd_gotoxy(13,3);
							lcd_puts("X\n");
							OCR0A = 242;
							estado1 = STANDBY;
							PORTD &= ~(1<<PD7);	// Turn Freezer [OFF]
						}

						var02 = read_keys();
						if(var02 == -1)
						var03 = !var03;

						if(var02 == 1)
						{
							estado2 = POWER2;
							lcd_clrscr();
						}
						break;

					case POWER2:
						lcd_gotoxy(4,1);
						lcd_puts("-Sleeping    \nOFF   \nON      \n");

						if(var06 == 0)
						{
							lcd_gotoxy(13,2);
							lcd_puts("X\n");
							lcd_gotoxy(13,3);
							lcd_puts(" \n");
						}
						else
						{
							lcd_gotoxy(13,2);
							lcd_puts(" \n");
							lcd_gotoxy(13,3);
							lcd_puts("X\n");
						}

						var02 = read_keys();
						if(var02 == -1)
						var06 = !var06;

						if(var02 == 1)
						{
							estado2 = HORA;
							lcd_clrscr();
						}
						break;

					case HORA:

						lcd_gotoxy(4,1);
						lcd_puts("-Ajuste Horas");


						sprintf(lcd_buffer,"%2.2d:",hour);
						lcd_gotoxy(6,2);
						lcd_puts(lcd_buffer);

						sprintf(lcd_buffer,"%2.2d:",min);
						lcd_puts(lcd_buffer);

						sprintf(lcd_buffer,"%2.2d",sec);
						lcd_puts(lcd_buffer);

						if(var05 == 0)
						{
							lcd_gotoxy(7,3);
							lcd_puts("X      ");
						}
						if(var05 == 1)
						{
							lcd_gotoxy(7,3);
							lcd_puts("   X   ");
						}
						if(var05 == 2)
						{
							lcd_gotoxy(7,3);
							lcd_puts("      X");
						}

						var02 = read_keys();
						if(var02 == 1)
						{
							if(var05 >= 2)
							{
								var05 = 0;
								estado2 = MODE;
								lcd_clrscr();
							}
							else
								var05++;
						}

						if(var02 == -1)
						{
							if(var05 == 0)
								hour++;
							if(var05 == 1)
								min++;
							if(var05 == 2)
								sec++;
						}

						if(hour == 24)
							hour = 0;
						if(min == 60)
							min = 0;
						if(sec == 60)
							sec = 0;

						time_adjust();

						break;

					default:
						break;
				}
			}
			lcd_clrscr();
			if(var03==0)
			estado1 = WAITING;	

			break;

		default:
			break;
	}
}

void automatic_Mode(void)
{
	p_Operacao = (int)(1320-temp[1])/10;

	Tmin = p_Operacao - 30;
	Tmax = p_Operacao + 30;
}

void time_adjust(void)
{
	if(sec >= 59)
	{
		sec = 0;
		if(min == 59)
		{
			min = 0;
			if(hour == 23)
				hour = 0;
			else
				hour++;
		}
		else
		{
			min++;
			minutes++;
		}
	}
}


void working(void)
{
	lcd_gotoxy(2,1);
	for(i=0;i<nSensors;i++)
	{
		if ( DS18X20_start_meas(DS18X20_POWER_PARASITE,&gSensorIDs[i][0]) == DS18X20_OK )
		{
			_delay_ms(DS18B20_TCONV_12BIT);

//			lcd_gotoxy(0,i+1);
//			sprintf(lcd_buffer,"T%d= ",i);
//			lcd_puts(lcd_buffer);

			if ( DS18X20_read_meas( &gSensorIDs[i][0], &subzero, &cel, &cel_frac_bits) == DS18X20_OK ) 
				lcd_put_temp(subzero, cel, cel_frac_bits);
		}
		else lcd_puts("Start meas. failed\n");

		temp[i] = DS18X20_temp_to_decicel(subzero, cel, cel_frac_bits);
	}

	if(!subzero)
	{
//		temp[0] = -temp[0];
		if(temp[0] <= Tmin)
		{
//			DDRD = (1<<PD7);
			PORTD &= ~(1<<PD7);	// Turn Freezer [OFF]

			if(flag)
			{
				timeON = minutes;
				eeprom_write_word((uint16_t *)4,timeON);
//				eeprom_write_byte((uint8_t *)1,timeON);

				minutes = 0;

				eficiencia = 100*timeON/(timeON+timeOFF);

				flag = !flag;
			}
		}

		if(temp[0] >= Tmax)
		{
//			DDRD = (1<<PD7);
			PORTD |= (1<<PD7);	// Turn Freezer [ON]

			if(!flag)
			{
				timeOFF = minutes;
				eeprom_write_word((uint16_t *)0,timeOFF);
//				eeprom_write_byte((uint8_t *)0,timeOFF);
				minutes = 0;

				eficiencia = 100*timeON/(timeON+timeOFF);

				flag = !flag;
			}
		}
			
	}
	else
		PORTD |= (1<<PD7);
}


void initializing(void)
{
	/* initialize display, cursor off */
	lcd_init(LCD_DISP_ON);
	
	/*  Procedure for searching sensors */
	nSensors = search_sensors();
	
	/* clear display and home cursor */
	lcd_clrscr();
	
	/* number of searched sensors */
	sprintf(lcd_buffer,"%d",(int)nSensors);
	lcd_puts(lcd_buffer);
	lcd_puts( "DS18x20 sensor(s)\n" );
	
	#ifdef DS18X20_VERBOSE
	for (i=0; i<nSensors; i++) {
		lcd_puts("# in Bus :");
		sprintf(lcd_buffer,"%d",(int) i+1);
		lcd_puts(lcd_buffer);
	}
	#endif
	
	/* delay before next operation */
	_delay_ms(2000);
	
	/* clear display and home cursor */
	lcd_clrscr();
	
	/* Types of searched sensors */
	for (i=0; i<nSensors; i++)
	{
		lcd_puts("S");
		sprintf(lcd_buffer,"%d#",(int) i+1);
		lcd_puts(lcd_buffer);
		lcd_puts(" is ");
		if ( gSensorIDs[i][0] == DS18S20_ID)
			lcd_puts("DS18S20/1820\n");
		else lcd_puts("DS18B20\n");
		
	}
	
	/* delay before next operation */
	_delay_ms(2000);
		
	if ( nSensors == 1 ) 
	{
		/* clear display and home cursor */
		lcd_clrscr();
		lcd_puts( "Only one sensor\n" ); 
		i = gSensorIDs[0][0]; // family-code for conversion-routine
		DS18X20_start_meas( DS18X20_POWER_PARASITE, NULL );
		_delay_ms(DS18B20_TCONV_12BIT);
		DS18X20_read_meas_single(i, &subzero, &cel, &cel_frac_bits);
		lcd_put_temp(subzero, cel, cel_frac_bits);
		/* delay before next operation */
		_delay_ms(2000);
	}
		
	/* clear display and home cursor */
	lcd_clrscr();
	lcd_puts( "Read sensors by one\n" );
	
	/* delay before next operation */
	_delay_ms(500);
	
	lcd_clrscr();
}
