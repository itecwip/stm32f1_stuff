#ifndef NR_CONVERSION_H
#define NR_CONVERSION_H

#include <stdint.h>

#define	BUFF_LEN								11

#define nr_convert2dec(num, outBuff)			nr_convertdata(num, 10, outBuff)
#define nr_convert2hex(num, outBuff)			nr_convertdata(num, 16, outBuff)

void nr_convertdata(uint32_t num, uint32_t base, char *outBuff);

#endif // NR_CONVERSION_H
