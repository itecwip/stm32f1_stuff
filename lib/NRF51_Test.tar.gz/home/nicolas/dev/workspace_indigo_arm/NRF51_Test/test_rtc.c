#include <string.h>
#include <stdbool.h>

#include "userlib.h"
// #include "nr_conversion.h"
// #include "uart.h"
// #include "onewire.h"

#define TX_PIN_NUMBER		(17)
#define RX_PIN_NUMBER		(19)

static char					str[CVT_DATA_LEN];

int main() {
	nr_sys_init();
	uart_config(TX_PIN_NUMBER, RX_PIN_NUMBER);
	uart_putstring((const uint8_t *) "RTC test:\r\n");

	uint32_t	mil;
	uint32_t	mic;

	for(;;) {
		mil = millis();
		mic = micros();
		nr_convert2dec(mil, str);
		uart_putstring((const uint8_t *)"millis() = ");
		uart_putstring((const uint8_t *)str);
		uart_putstring((const uint8_t *)"\r\n");
		nr_convert2dec(mic, str);
		uart_putstring((const uint8_t *)"micro() = ");
		uart_putstring((const uint8_t *)str);
		uart_putstring((const uint8_t *)"\r\n");

		delayMicroseconds(500);
	}
	uart_putstring((const uint8_t *)"End of program.");
	do {} while (1);

	return 0;
}
