#include <string.h>
#include <stdbool.h>

#include "nrf_delay.h"
#include "nr_conversion.h"
#include "uart.h"
#include "onewire.h"

#define TX_PIN_NUMBER		(17)
#define RX_PIN_NUMBER		(19)

#define ONEWIRE_PIN			(20UL)

static onewire_search_t		ow;
static char					str[30];

typedef struct {
    uint32_t	addr32_1;
    uint32_t	addr32_2;
} data_addr_32;


typedef struct {
    union {
    	uint8_t			addr[8];
    	data_addr_32	ad32;
    };
} data_addr;

int main() {

	data_addr	addr;
	uint8_t		data[12];
	uint8_t		present;
	uint8_t		type_s;
	// float celsius, fahrenheit;
	bool		flag;

	uart_config(TX_PIN_NUMBER, RX_PIN_NUMBER);

	uart_putstring((const uint8_t *) "One wire test:\r\n");

	onewire_init(ONEWIRE_PIN);
	onewire_reset_search(&ow);

	do {
		if (!onewire_search(&ow, ONEWIRE_PIN, addr.addr)) {
			uart_putstring((const uint8_t *) "No more addresses.\r\n\r\n");
			onewire_reset_search(&ow);
			nrf_delay_ms(250);
		}
		uart_putstring((const uint8_t *) "ROM =");
		for (uint8_t i = 0; i < 8; i++) {
			uart_put(' ');
			nr_convert2hex(addr.addr[i], str);
			uart_putstring((const uint8_t *) str);
		}
		if (onewire_crc8(addr.addr, 7) != addr.addr[7]) {
			uart_putstring((const uint8_t *) "CRC is not valid!");
			break;
		}
		uart_put('\r');
		uart_put('\n');
		uart_putstring((const uint8_t *) "data[");
		nr_convert2hex(addr.ad32.addr32_1, str);
		uart_putstring((const uint8_t *) str);
		nr_convert2hex(addr.ad32.addr32_2, str);
		uart_putstring((const uint8_t *) str);
		uart_putstring((const uint8_t *) "]\r\n");
		// the first ROM byte indicates which chip
		flag = false;
		switch (addr.addr[0]) {
		case 0x10:
			uart_putstring((const uint8_t *)"  Chip = DS18S20");  // or old DS1820
			type_s = 1;
			break;
		case 0x28:
			uart_putstring((const uint8_t *)"  Chip = DS18B20");
			type_s = 0;
			break;
		case 0x22:
			uart_putstring((const uint8_t *)"  Chip = DS1822");
			type_s = 0;
			break;
		default:
			uart_putstring((const uint8_t *)"Device is not a DS18x20 family device.");
			flag = true;
			break;
		}
		if (flag) {
			break;
		}
		onewire_reset(ONEWIRE_PIN);
		onewire_select(ONEWIRE_PIN, addr.addr);
		onewire_write(ONEWIRE_PIN, 0x44, 1);        // start conversion, with parasite power on at the end

		nrf_delay_ms(1000);     // maybe 750ms is enough, maybe not
		// we might do a ds.depower() here, but the reset will take care of it.

		present = onewire_reset(ONEWIRE_PIN);
		onewire_select(ONEWIRE_PIN, addr.addr);
		onewire_write(ONEWIRE_PIN, 0xBE, 0);         // Read Scratchpad

		uart_putstring((const uint8_t *)"  Data = (");
		nr_convert2hex(present, str);
		// sprintf(str, "%02x", present);
		uart_putstring((const uint8_t *) str);
		uart_putstring((const uint8_t *)") ");
		for (uint8_t i = 0; i < 9; i++) {           // we need 9 bytes
			data[i] = onewire_read(ONEWIRE_PIN);
			nr_convert2hex(data[i], str);
			// sprintf(str, "%02x", data[i]);
			uart_putstring((const uint8_t *) str);
			uart_putstring((const uint8_t *)" ");
		}
		uart_putstring((const uint8_t *)" CRC = ");
		nr_convert2hex(onewire_crc8(data, 8), str);
		// sprintf(str, "%02x", onewire_crc8(data, 8));
		uart_putstring((const uint8_t *) str);
		uart_put('\r');
		uart_put('\n');

		// Convert the data to actual temperature
		// because the result is a 16 bit signed integer, it should
		// be stored to an "int16_t" type, which is always 16 bits
		// even when compiled on a 32 bit processor.
		int16_t raw = (data[1] << 8) | data[0];
		if (type_s) {
			raw = raw << 3; // 9 bit resolution default
			if (data[7] == 0x10) {
				// "count remain" gives full 12 bit resolution
				raw = (raw & 0xFFF0) + 12 - data[6];
			}
		} else {
			uint8_t cfg = (data[4] & 0x60);
			// at lower res, the low bits are undefined, so let's zero them
			if (cfg == 0x00) raw = raw & ~7;  // 9 bit resolution, 93.75 ms
			else if (cfg == 0x20) raw = raw & ~3; // 10 bit res, 187.5 ms
			else if (cfg == 0x40) raw = raw & ~1; // 11 bit res, 375 ms
			//// default is 12 bit resolution, 750 ms conversion time
		}
		// celsius = (float)raw / 16.0;
		uart_putstring((const uint8_t *)"  Temperature = ");
		// sprintf(str, "%f", celsius);
		nr_convert2hex(raw, str);
		uart_putstring((const uint8_t *) str);
		uart_putstring((const uint8_t *)" Celsius.");
		uart_put('\r');
		uart_put('\n');
	} while (1);

	uart_putstring((const uint8_t *)"End of program.");
	do {} while (0);

	return 0;
}
