#include <string.h>
#include <stdbool.h>

#include "userlib.h"
// #include "nr_conversion.h"
// #include "uart.h"
// #include "onewire.h"

void fWrite(const uint8_t what) {
}

uint8_t fAvailable() {
   return 0x01;
   }

uint8_t fRead() {
   return '1';
}

static rs485_nb_instance_t	rs485;

int main() {
	nr_sys_init();
	init_rs485_nb(&rs485, fRead, fAvailable, fWrite, 255);

	do {
		rs485_nb_begin(&rs485);

		rs485_nb_stop(&rs485);
	} while(1);
	release_rs485_nb(&rs485);

	return 0;
}
