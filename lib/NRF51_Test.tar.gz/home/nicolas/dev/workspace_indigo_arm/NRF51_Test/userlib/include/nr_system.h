#ifndef NR_SYSTEM_H
#define NR_SYSTEM_H

#include <stdint.h>

#include "userconf.h"

#if (USERLIB_USE_SYS == YES)

/*
 * Initialize RTC
 * Uses NRF RTC1
 */
void nr_sys_init(void);

/**
 * Weak function (by default do nothing, can be overwritten)
 *
 * Used to implement a real cooperative scheduler.
 * Called by delay()
 */
void yield(void);

/**
 * \brief Returns the number of milliseconds since the Arduino board began running the current program.
 *
 * This number will overflow (go back to zero), after approximately 50 days.
 *
 * \return Number of milliseconds since the program started (uint32_t)
 */
uint32_t millis(void);

/**
 * \brief Returns the number of microseconds since the Arduino board began running the current program.
 *
 * This number will overflow (go back to zero), after approximately 70 minutes. On 16 MHz Arduino boards
 * (e.g. Duemilanove and Nano), this function has a resolution of four microseconds (i.e. the value returned is
 * always a multiple of four). On 8 MHz Arduino boards (e.g. the LilyPad), this function has a resolution
 * of eight microseconds.
 *
 * \note There are 1,000 microseconds in a millisecond and 1,000,000 microseconds in a second.
 * Uses RTC1
 */
uint32_t micros(void);

/**
 * \brief Pauses the program for the amount of time (in miliseconds) specified as parameter.
 * (There are 1000 milliseconds in a second.)
 *
 * \param dwMs the number of milliseconds to pause (uint32_t)
 */
void delay(uint32_t dwMs);


#endif /* USERLIB_USE_SYS == YES */
#endif // NR_SYSTEM_H
