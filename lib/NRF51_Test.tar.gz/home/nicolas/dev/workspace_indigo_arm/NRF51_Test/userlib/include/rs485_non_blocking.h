/*
 RS485 protocol library - non-blocking.
 
 Devised and written by Nick Gammon.
 Date: 4 December 2012
 Version: 1.0
 
 Licence: Released for public use.
 
*/

#ifndef _RS485_NB_H_
#define _RS485_NB_H_

#include <stdint.h>
#include <stdbool.h>

#include "userconf.h"

#if (USERLIB_USE_RS485_NB == YES)


typedef void (*NBWriteCallback)(const uint8_t what);		// send a uint8_t to serial port
typedef uint8_t (*NBAvailableCallback)();    				// return number of bytes available
typedef uint8_t (*NBReadCallback)();    					// read a uint8_t from serial port

typedef struct
{
	  // callback functions to do reading/writing
	NBReadCallback		fReadCallback_;
	NBAvailableCallback	fAvailableCallback_;
	NBWriteCallback		fWriteCallback_;

	uint8_t 			*data_;			// where we save incoming stuff
	uint8_t				bufferSize_;	// how much data is in the buffer
	bool				available_;		// this is true once we have valid data in buf
	bool				haveSTX_;		// an STX (start of text) signals a packet start
	uint32_t			errorCount_;	// count of errors

  
	bool				haveETX_;	// variables below are set when we get an STX
	uint8_t				inputPos_;
	uint8_t				currentByte_;
	bool				firstNibble_;
	uint32_t			startTime_;
} rs485_nb_instance_t;

// constructor
void init_rs485_nb(rs485_nb_instance_t *p_instance,
		NBReadCallback fReadCallback, NBAvailableCallback fAvailableCallback, NBWriteCallback fWriteCallback, const uint8_t bufferSize);

void release_rs485_nb(rs485_nb_instance_t *p_instance);
  
// allocate memory for buf_
void rs485_nb_begin(rs485_nb_instance_t *p_instance);
    
// free memory in buf_
void rs485_nb_stop(rs485_nb_instance_t *p_instance);
  
// handle incoming data, return true if packet ready
bool rs485_nb_update(rs485_nb_instance_t *p_instance);
  
// reset to no incoming data (eg. after a timeout)
void rs485_nb_reset(rs485_nb_instance_t *p_instance);
  
// send data
void rs485_nb_sendMsg(rs485_nb_instance_t *p_instance, const uint8_t * data, const uint8_t length);
  
    // returns true if packet available
static inline bool rs485_nb_available(rs485_nb_instance_t *p_instance) {
	return p_instance->available_;
};
  
// once available, returns the address of the current message
static inline const uint8_t *rs485_nb_getData(rs485_nb_instance_t *p_instance) {
	return p_instance->data_;
}

static inline const uint8_t rs485_nb_getLength(rs485_nb_instance_t *p_instance) {
	return p_instance->inputPos_;
}
    
// return how many errors we have had
static inline uint32_t rs485_nb_getErrorCount(rs485_nb_instance_t const *p_instance) {
	return p_instance->errorCount_;
}
  
// return when last packet started
static inline uint32_t rs485_nb_getPacketStartTime(rs485_nb_instance_t *p_instance) {
	return p_instance->startTime_;
}
  
// return true if a packet has started to be received
static inline bool rs485_nb_isPacketStarted(rs485_nb_instance_t *p_instance) {
	return p_instance->haveSTX_;
}
  

#endif /* USERLIB_USE_RS485_NB == YES */

#endif /* _RS485_NB_H_ */
