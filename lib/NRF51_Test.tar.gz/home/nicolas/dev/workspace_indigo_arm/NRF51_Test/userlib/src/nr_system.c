#include "nrf.h"

#include "nr_system.h"

//void __libc_init_array(void);
void rtc_config(void);
void RTC1_Interrupt(void);

// widen rtc1 to 40-bit (1099511627775 ticks = 33554431999969us = 388 days)
// (dont overflow uint64_t when multipying by 1000000)
volatile uint64_t rtc1 = 0;

void nr_sys_init(void)
{
	// Initialize 16 MHz crystal oscillator. 470uA + 1.1mA@400us Startup current
	NRF_CLOCK->EVENTS_HFCLKSTARTED  = 0;
	NRF_CLOCK->TASKS_HFCLKSTART = 1;
	// Wait until oscillator startup is finished
	while (NRF_CLOCK->EVENTS_HFCLKSTARTED == 0) { }
	NRF_CLOCK->EVENTS_HFCLKSTARTED = 0;

	// Start 32768Hz Clock for RTC
	// External oscillator 0.4uA + 1.3uA@300ms Startup current
	NRF_CLOCK->LFCLKSRC = (CLOCK_LFCLKSRC_SRC_Xtal << CLOCK_LFCLKSRC_SRC_Pos);
	NRF_CLOCK->EVENTS_LFCLKSTARTED = 0;
	NRF_CLOCK->TASKS_LFCLKSTART = 1;
	// Wait until oscillator startup is finished
	while (NRF_CLOCK->EVENTS_LFCLKSTARTED == 0) { }
	NRF_CLOCK->EVENTS_LFCLKSTARTED = 0;

	// Initialize C library
	// __libc_init_array();

	// NRF51822 doesn't implement SysTick, so use the RTC for timing
	rtc_config();
}

void rtc_config(void)
{
	NRF_RTC1->TASKS_STOP = 1;	// Stop RTC timer
	NRF_RTC1->TASKS_CLEAR = 1;	// Clear timer
	NRF_RTC1->PRESCALER = 0;	// No prescaling => 1 tick = 1/32768Hz = 30.517us
	NRF_RTC1->EVTENSET = (RTC_EVTENSET_OVRFLW_Set << RTC_EVTENSET_OVRFLW_Pos); // Enable OVRFLW Event
	NRF_RTC1->INTENSET = (RTC_INTENSET_OVRFLW_Set << RTC_INTENSET_OVRFLW_Pos); // Enable OVRFLW Interrupt

	NVIC_ClearPendingIRQ(RTC1_IRQn);
	NVIC_EnableIRQ(RTC1_IRQn);		// Enable Interrupt for the RTC in the core

	NRF_RTC1->TASKS_START = 1;	// Start RTC
}

/*
 * Real time clock controller 1
 */
void RTC1_Interrupt(void)
{
	if (NRF_RTC1->EVENTS_OVRFLW) {
		// extend counter
		rtc1 += 0x1000000LLU;
		// truncate to 40-bit
		rtc1 &= 0xffffffffffLLU;
		NRF_RTC1->EVENTS_OVRFLW = 0;
	}

	NRF_RTC1->EVENTS_COMPARE[0] = 0;
}

uint32_t millis(void)
{
	return (uint32_t)((rtc1 + NRF_RTC1->COUNTER) * 1000 >> 15);  // divide by 32768
}

uint32_t micros(void)
{
	// accurate to 30.517us
	return (uint32_t)((rtc1 + NRF_RTC1->COUNTER) * 1000000 >> 15);  // divide by 32768
}

void delay(uint32_t ms)
{
	uint32_t start = millis();
	while (millis() - start < ms) {
		yield();
	}
}

void delayMicroseconds(uint32_t us)
{
    while (us--) {
        __ASM(" NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t");
    };
}


/**
 * Empty yield() hook.
 *
 * This function is intended to be used by library writers to build
 * libraries or sketches that supports cooperative threads.
 *
 * Its defined as a weak symbol and it can be redefined to implement a
 * real cooperative scheduler.
 */
static void __empty() {
	// Empty
}
void yield(void) __attribute__ ((weak, alias("__empty")));

