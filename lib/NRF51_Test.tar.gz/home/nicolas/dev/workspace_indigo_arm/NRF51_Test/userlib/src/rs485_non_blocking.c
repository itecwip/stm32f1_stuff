/*
 RS485 protocol library - non-blocking.

 Devised and written by Nick Gammon.
 Date: 4 December 2012
 Version: 1.0

 Licence: Released for public use.


 Can send from 1 to 255 bytes from one node to another with:

 * Packet start indicator (STX)
 * Each data byte is doubled and inverted to check validity
 * Packet end indicator (ETX)
 * Packet CRC (checksum)


 To allow flexibility with hardware (eg. Serial, SoftwareSerial, I2C)
 you provide three "callback" functions which send or receive data. Examples are:

 size_t fWrite (const byte what)
   {
   return Serial.write (what);  
   }

 int fAvailable ()
   {
   return Serial.available ();  
   }

 int fRead ()
   {
   return Serial.read ();  
   }

 */

#include <stdlib.h>
#include <nr_system.h>

#include <rs485_non_blocking.h>

#define STX		0x02		// start of text
#define ETX		0x03		// end of text


void init_rs485_nb(rs485_nb_instance_t *p_instance,
		NBReadCallback fReadCallback, NBAvailableCallback fAvailableCallback, NBWriteCallback fWriteCallback,
		const uint8_t bufferSize) {
	p_instance->fReadCallback_= fReadCallback;
	p_instance->fAvailableCallback_ = fAvailableCallback;
	p_instance->fWriteCallback_ = fWriteCallback;
	p_instance->bufferSize_ = bufferSize;
	p_instance->data_ = NULL;
}

void release_rs485_nb(rs485_nb_instance_t *p_instance) {
	rs485_nb_stop(p_instance);
}

// allocate the requested buffer size
void rs485_nb_begin(rs485_nb_instance_t *p_instance) {
	p_instance->data_ = (uint8_t *) malloc(p_instance->bufferSize_);
	rs485_nb_reset(p_instance);
	p_instance->errorCount_ = 0;
} // end of begin

// get rid of the buffer
void rs485_nb_stop(rs485_nb_instance_t *p_instance)
{
	rs485_nb_reset(p_instance);
	free(p_instance->data_);
	p_instance->data_ = NULL;
} // end of stop

// called after an error to return to "not in a packet"
void rs485_nb_reset(rs485_nb_instance_t *p_instance)
{
	p_instance->haveSTX_ = false;
	p_instance->available_ = false;
	p_instance->inputPos_ = 0;
	p_instance->startTime_ = 0;
} // end of reset

// calculate 8-bit CRC
uint8_t rs485_nb_crc8(const uint8_t *addr, uint8_t len)
{
	uint8_t crc = 0;
	while (len--)  {
		uint8_t inbyte = *addr++;
		for (uint8_t i = 8; i; i--) {
			uint8_t mix = (crc ^ inbyte) & 0x01;
			crc >>= 1;
			if (mix) {
				crc ^= 0x8C;
			}
			inbyte >>= 1;
		}  // end of for
	}  // end of while
	return crc;
}  // end of crc8

// send a byte complemented, repeated
// only values sent would be (in hex): 
//   0F, 1E, 2D, 3C, 4B, 5A, 69, 78, 87, 96, A5, B4, C3, D2, E1, F0
void rs485_nb_sendComplemented(rs485_nb_instance_t *p_instance, const uint8_t what) {
	uint8_t c;

	// first nibble
	c = what >> 4;
	p_instance->fWriteCallback_((c << 4) | (c ^ 0x0F));

	// second nibble
	c = what & 0x0F;
	p_instance->fWriteCallback_((c << 4) | (c ^ 0x0F));

}  // end of sendComplemented

// send a message of "length" bytes (max 255) to other end
// put STX at start, ETX at end, and add CRC
void rs485_nb_sendMsg(rs485_nb_instance_t *p_instance, const uint8_t *data, const uint8_t length) {
	// no callback? Can't send
	if (p_instance->fWriteCallback_ == NULL)
		return;

	p_instance->fWriteCallback_(STX);  // STX
	for (uint8_t i = 0; i < length; i++) {
		rs485_nb_sendComplemented(p_instance, data[i]);
	}
	p_instance->fWriteCallback_(ETX);  // ETX
	rs485_nb_sendComplemented(p_instance, rs485_nb_crc8(data, length));
}  // end of sendMsg

// called periodically from main loop to process data and 
// assemble the finished packet in 'data_'

// returns true if packet received.

// You could implement a timeout by seeing if isPacketStarted() returns
// true, and if too much time has passed since getPacketStartTime() time.

bool rs485_nb_update(rs485_nb_instance_t *p_instance) {
	// no data? can't go ahead (eg. begin() not called)
	if (p_instance->data_ == NULL)
		return false;

	// no callbacks? Can't read
	if (p_instance->fAvailableCallback_ == NULL || p_instance->fReadCallback_ == NULL)
		return false;

	while (p_instance->fAvailableCallback_() > 0)  {
		uint8_t inByte = p_instance->fReadCallback_();

		switch (inByte) {

		case STX:   // start of text
			p_instance->haveSTX_ = true;
			p_instance->haveETX_ = false;
			p_instance->inputPos_ = 0;
			p_instance->firstNibble_ = true;
			p_instance->startTime_ = millis();
			break;

		case ETX:   // end of text (now expect the CRC check)
			p_instance->haveETX_ = true;
			break;

		default:
			// wait until packet officially starts
			if (!p_instance->haveSTX_)
				break;

			// check byte is in valid form (4 bits followed by 4 bits complemented)
			if ((inByte >> 4) != ((inByte & 0x0F) ^ 0x0F)) {
				rs485_nb_reset(p_instance);
				p_instance->errorCount_++;
				break;  // bad character
			} // end if bad byte

			// convert back
			inByte >>= 4;

			// high-order nibble?
			if (p_instance->firstNibble_) {
				p_instance->currentByte_ = inByte;
				p_instance->firstNibble_ = false;
				break;
			}  // end of first nibble

			// low-order nibble
			p_instance->currentByte_ <<= 4;
			p_instance->currentByte_ |= inByte;
			p_instance->firstNibble_ = true;

			// if we have the ETX this must be the CRC
			if (p_instance->haveETX_) {
				if (rs485_nb_crc8(p_instance->data_, p_instance->inputPos_) != p_instance->currentByte_) {
					rs485_nb_reset(p_instance);
					p_instance->errorCount_++;
					break;  // bad crc
				} // end of bad CRC

				p_instance->available_ = true;
				return true;  // show data ready
			}  // end if have ETX already

			// keep adding if not full
			if (p_instance->inputPos_ < p_instance->bufferSize_) {
				p_instance->data_[p_instance->inputPos_++] = p_instance->currentByte_;
			} else {
				rs485_nb_reset(p_instance); // overflow, start again
				p_instance->errorCount_++;
			}

			break;

		}  // end of switch
	}  // end of while incoming data

	return false;  // not ready yet
} // end of update

