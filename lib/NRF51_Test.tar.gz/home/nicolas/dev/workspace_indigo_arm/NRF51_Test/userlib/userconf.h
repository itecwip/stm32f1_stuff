/**
 * @file    userconf.h
 * @brief   Userlib configuration header.
 * @details Userlib configuration file, this file allows to enable or disable the
 *          various device drivers from your application. You may also use
 *          this file in order to override the device drivers default settings.
 *
 * @addtogroup USER_CONF
 * @{
 */

#ifndef _USERCONF_H_
#define _USERCONF_H_

#define	YES		1
#define	NO		0

/**
 * @brief   Enables the conversion
 */
#if !defined(USERLIB_USE_CONV)
#define USERLIB_USE_CONV			NO
#endif

/**
 * @brief   Enables the UART read/write characters
 */
#if !defined(USERLIB_USE_UART)
#define USERLIB_USE_UART			NO
#endif

/**
 * @brief   Enables the One wire subsystem.
 */
#if !defined(USERLIB_USE_ONEWIRE)
#define USERLIB_USE_ONEWIRE			NO
#endif

/**
 * @brief   Enables the system utilities (rtc, millis(), delay(), ...).
 */
#if !defined(USERLIB_USE_SYS)
#define USERLIB_USE_SYS				YES
#endif

/**
 * @brief   Enables the RS485 blocking protocol
 */
#if !defined(USERLIB_USE_RS485)
#define USERLIB_USE_RS485			YES
#endif

/**
 * @brief   Enables the RS485 non blocking protocol
 */
#if !defined(USERLIB_USE_RS485_NB)
#define USERLIB_USE_RS485_NB		YES
#endif

#endif /* _USERCONF_H_ */

/** @} */
