 /* Copyright (c) 2012 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */

#ifndef UART_H
#define UART_H

#include "userconf.h"

#if (USERLIB_USE_UART == YES)

/** Reads a character from UART.
Execution is blocked until UART peripheral detects character has been received.
\return cr Received character.
*/
uint8_t uart_get(void);


/** Sends a character to UART.
Execution is blocked until UART peripheral reports character to have been send.
@param cr Character to send.
*/
void uart_put(uint8_t cr);

/** Sends a string to UART.
Execution is blocked until UART peripheral reports all characters to have been send.
Maximum string length is 254 characters including null character in the end.
@param str Null terminated string to send.
*/
void uart_putstring(const uint8_t *str);

/** Configures UART to use 38400 baud rate.
@param txd_pin_number Chip pin number to be used for UART TXD
@param rxd_pin_number Chip pin number to be used for UART RXD
*/
void uart_config(uint8_t txd_pin_number, uint8_t rxd_pin_number);

#endif /* USERLIB_USE_UART == YES */
#endif
