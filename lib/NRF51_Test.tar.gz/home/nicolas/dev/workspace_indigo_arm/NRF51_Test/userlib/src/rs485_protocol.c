/*
 RS485 protocol library.

 Devised and written by Nick Gammon.
 Date: 14 November 2011
 Version: 1.1

 Version 1.1 reset the timeout period after getting STX.

 Licence: Released for public use.


 Can send from 1 to 255 bytes from one node to another with:

 * Packet start indicator (STX)
 * Each data byte is doubled and inverted to check validity
 * Packet end indicator (ETX)
 * Packet CRC (checksum)


 To allow flexibility with hardware (eg. Serial, SoftwareSerial, I2C)
 you provide three "callback" functions which send or receive data. Examples are:

 void fWrite (const byte what)
 {
 Serial.write (what);  
 }

 int fAvailable ()
 {
 return Serial.available ();  
 }

 int fRead ()
 {
 return Serial.read ();  
 }

 */

#include <stdbool.h>
#include <nr_system.h>
#include <rs485_protocol.h>

#define STX		0x02		// start of text
#define ETX		0x03		// end of text


// calculate 8-bit CRC
static uint8_t crc8(const uint8_t *addr, uint8_t len)
{
	uint8_t crc = 0;

	while (len--) {
		uint8_t inbyte = *addr++;
		for (uint8_t i = 8; i; i--) {
			uint8_t mix = (crc ^ inbyte) & 0x01;
			crc >>= 1;
			if (mix) {
				crc ^= 0x8C;
			}
			inbyte >>= 1;
		}  // end of for
	}  // end of while
	return crc;
}  // end of crc8

// send a byte complemented, repeated
// only values sent would be (in hex): 
//   0F, 1E, 2D, 3C, 4B, 5A, 69, 78, 87, 96, A5, B4, C3, D2, E1, F0
void sendComplemented(WriteCallback fSend, const uint8_t what)
{
	uint8_t c;

	// first nibble
	c = what >> 4;
	fSend((c << 4) | (c ^ 0x0F));

	// second nibble
	c = what & 0x0F;
	fSend((c << 4) | (c ^ 0x0F));

}  // end of sendComplemented

// send a message of "length" bytes (max 255) to other end
// put STX at start, ETX at end, and add CRC
void sendMsg(WriteCallback fSend, const uint8_t *data, const uint8_t length)
{
	fSend(STX);  // STX
	for (uint8_t i = 0; i < length; i++) {
		sendComplemented(fSend, data[i]);
	}
	fSend(ETX);  // ETX
	sendComplemented(fSend, crc8(data, length));
}  // end of sendMsg

// receive a message, maximum "length" bytes, timeout after "timeout" milliseconds
// if nothing received, or an error (eg. bad CRC, bad data) return 0
// otherwise, returns length of received data
uint8_t recvMsg(AvailableCallback	fAvailable,	// return available count
		ReadCallback			fRead,		// read one byte
		uint8_t				*data,		// buffer to receive into
		const uint8_t			length,		// maximum buffer size
		uint32_t				timeout)	// milliseconds before timing out
{

	uint32_t start_time = millis();

	bool have_stx = false;

	// variables below are set when we get an STX
	bool		have_etx = false;
	uint8_t	input_pos = 0;
	bool		first_nibble = false;
	uint8_t	current_byte = 0;

	while (millis () - start_time < timeout) {
		if (fAvailable () > 0)  {
			uint8_t inByte = fRead();

			switch (inByte) {

			case STX:   // start of text
				have_stx = true;
				have_etx = false;
				input_pos = 0;
				first_nibble = true;
				start_time = millis();  // reset timeout period
				break;

			case ETX:   // end of text
				have_etx = true;
				break;

			default:
				// wait until packet officially starts
				if (!have_stx) {
					break;
				}

				// check byte is in valid form (4 bits followed by 4 bits complemented)
				if ((inByte >> 4) != ((inByte & 0x0F) ^ 0x0F) ) {
					return 0;  // bad character
				}

				// convert back
				inByte >>= 4;

				// high-order nibble?
				if (first_nibble) {
					current_byte = inByte;
					first_nibble = false;
					break;
				}  // end of first nibble

				// low-order nibble
				current_byte <<= 4;
				current_byte |= inByte;
				first_nibble = true;

				// if we have the ETX this must be the CRC
				if (have_etx) {
					if (crc8(data, input_pos) != current_byte) {
						return 0;  // bad crc
					}
					return input_pos;  // return received length
				}  // end if have ETX already

				// keep adding if not full
				if (input_pos < length) {
					data [input_pos++] = current_byte;
				} else {
					return 0;  // overflow
				}
				break;

			}  // end of switch
		}  // end of incoming data
	} // end of while not timed out

	return 0;  // timeout
} // end of recvMsg

