#ifndef _RS485_H_
#define _RS485_H_

#include <stdint.h>

#include "userconf.h"

#if (USERLIB_USE_RS485 == YES)

typedef void (*WriteCallback)(const uint8_t what);	// send a byte to serial port
typedef uint8_t (*AvailableCallback)();				// return number of bytes available
typedef uint8_t (*ReadCallback)();					// read a byte from serial port


void sendMsg(WriteCallback fSend, const uint8_t *data, const uint8_t length);

uint8_t recvMsg(AvailableCallback fAvailable, ReadCallback fRead, uint8_t *data, const uint8_t length, uint32_t timeout/* = 500*/);


#endif /* USERLIB_USE_RS485 == YES */

#endif /* _RS485_H_ */
