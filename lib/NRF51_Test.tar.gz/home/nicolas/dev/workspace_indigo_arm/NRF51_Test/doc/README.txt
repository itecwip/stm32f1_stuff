Programmation du NRF51 avec la cl� USB stlink-v2
=================================================

Brancher la cl� stlink-v2 connect�e la carte NRF51.
Lancer 2 consoles

Sur la premi�re:
----------------
$ cd /home/nicolas/dev/arm/tools/bin
$ ./run_nrf.sh

Sur la deuxi�me:
----------------
$ telnet 127.0.0.1 4444

halt

nrf51 mass_erase

reset
halt

flash write_image erase <fichier_hex> 0

reset

exit

$

Liste des images (*.hex)

/home/nicolas/dev/workspace_indigo_arm/NRF51_Test/test_ow.hex
/home/nicolas/dev/workspace_indigo_arm/NRF51_Test/rtc.hex


Configuration Arduino uno en mode USB to serial:
================================================
Installer un jumper sur les broches 5-6 du connecteur ISCP de l'arduino uno. (pins cot� MCU 328p).
Mise en reset permanent de l'Arduino uno.

D�brancher la carte arduino uno.
Brancher la broche 1 (TX) sur la sortie de la carte d'essai (transmission).
Brancher la broche 0 (RX) sur l'entr�e de la carte d'essai (r�ception).
Brancher la broche GND au moins de la carte d'essai.
Brancher la carte arduino uno.

Lancer le programme de transmission sur le device /dev/ttyACM0 (9600,8,N,1)

