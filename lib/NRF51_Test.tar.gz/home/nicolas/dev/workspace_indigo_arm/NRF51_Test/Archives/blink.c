//#include <nrf.h>

#include <stdbool.h>
#include <stdint.h>

#include "nrf_delay.h"
#include "nrf_gpio.h"



#define PIN17_GPIO  (17UL)
#define PIN18_GPIO  (18UL)
#define PIN19_GPIO  (19UL)
#define PIN20_GPIO  (20UL)



/*
 * Port dispo : 17, 18, 19, 20
 */


int main(void)
{
	uint32_t		pin_number = PIN17_GPIO;

    // Configure LED-pins as outputs.
	nrf_gpio_cfg_output(PIN17_GPIO);
	nrf_gpio_cfg_output(PIN18_GPIO);
	nrf_gpio_cfg_output(PIN19_GPIO);
	nrf_gpio_cfg_output(PIN20_GPIO);

    // Toggle LEDs.
    while (true) {
    	if (pin_number == PIN17_GPIO) {
    		nrf_gpio_pin_toggle(pin_number++);
    	} else if (pin_number == PIN18_GPIO) {
    		nrf_gpio_pin_toggle(pin_number++);
     	} else if (pin_number == PIN19_GPIO) {
    		nrf_gpio_pin_toggle(pin_number++);
    	} else if (pin_number == PIN20_GPIO) {
    		nrf_gpio_pin_toggle(pin_number);
    		pin_number = PIN17_GPIO;
    	}
        nrf_delay_ms(500);
    }
}
