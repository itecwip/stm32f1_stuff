#include <nrf.h>
#include "uart.h"

#define TX_PIN_NUMBER        (17)
#define RX_PIN_NUMBER        (19)

int main(void)
{
	uint8_t c;

	uart_config(TX_PIN_NUMBER, RX_PIN_NUMBER);

	uart_putstring((const uint8_t *)"Enter a character:\r\n");
	while(1) {
		c = uart_get();
		uart_put(c);
	}
	return 0;
}
