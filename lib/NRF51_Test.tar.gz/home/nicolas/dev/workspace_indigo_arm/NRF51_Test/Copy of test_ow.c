/*
   text	   data	    bss	    dec	    hex	filename
   6252	   1092	     72	   7416	   1cf8	test_ow.elf

   3520	   1064	     40	   4624	   1210	test_ow.elf

nano:
   text	   data	    bss	    dec	    hex	filename
   2868	     96	     40	   3004	    bbc	test_ow.elf
*/

#include <string.h>
#include <stdbool.h>

#include "nrf_delay.h"
#include "userlib.h"
// #include "nr_conversion.h"
// #include "uart.h"
// #include "onewire.h"

#define TX_PIN_NUMBER		(17)
#define RX_PIN_NUMBER		(19)

#define ONEWIRE_PIN			(20UL)

static onewire_search_t		ow;
static char					str[CVT_DATA_LEN];
static char					strbuff[CVT_BUFF_LEN];

int main() {

	uint8_t		addr[8];
	uint8_t		data[12];

	uart_config(TX_PIN_NUMBER, RX_PIN_NUMBER);

	uart_putstring((const uint8_t *) "One wire test:\r\n");

	onewire_init(ONEWIRE_PIN);
	onewire_reset_search(&ow);

	do {
		if (!onewire_search(&ow, ONEWIRE_PIN, addr)) {
			uart_putstring((const uint8_t *) "No more addresses.\r\n");
			onewire_reset_search(&ow);
			nrf_delay_ms(250);
		}
		if (onewire_crc8(addr, 7) != addr[7]) {
			uart_putstring((const uint8_t *) "CRC is not valid!");
			break;
		}
		// the first ROM byte indicates which chip
		if (addr[0] != 0x28) {
			uart_putstring((const uint8_t *)"Device is not a DS18x20 family device.");
			break;
		}
		onewire_reset(ONEWIRE_PIN);
		onewire_select(ONEWIRE_PIN, addr);
		onewire_write(ONEWIRE_PIN, 0x44, 1);        // start conversion, with parasite power on at the end

		nrf_delay_ms(1000);     // maybe 750ms is enough, maybe not
		// we might do a ds.depower() here, but the reset will take care of it.

		onewire_reset(ONEWIRE_PIN);
		onewire_select(ONEWIRE_PIN, addr);
		onewire_write(ONEWIRE_PIN, 0xBE, 0);         // Read Scratchpad

		for (uint8_t i = 0; i < 9; i++) {           // we need 9 bytes
			data[i] = onewire_read(ONEWIRE_PIN);
		}
		int16_t raw = (data[1] << 8) | data[0];
		uint8_t cfg = (data[4] & 0x60);
		// at lower res, the low bits are undefined, so let's zero them
		if (cfg == 0x00) raw = raw & ~7;  // 9 bit resolution, 93.75 ms
		else if (cfg == 0x20) raw = raw & ~3; // 10 bit res, 187.5 ms
		else if (cfg == 0x40) raw = raw & ~1; // 11 bit res, 375 ms
		//// default is 12 bit resolution, 750 ms conversion time
		nr_convert2dec(raw / 16, str);
		nr_convertdata2hex(addr, strbuff);
		uart_putstring((const uint8_t *)"[");
		uart_putstring((const uint8_t *)strbuff);
		uart_putstring((const uint8_t *)"] Temperature = ");
		uart_putstring((const uint8_t *)str);
		uart_putstring((const uint8_t *)"�C\r\n");
	} while (1);

	uart_putstring((const uint8_t *)"End of program.");
	do {} while (1);

	return 0;
}
