
#include "nr_conversion.h"

void nr_convertdata(uint32_t num, uint32_t base, char *outBuff) {
	char	data[11];
	char	*str = &data[sizeof(data) -1];

	*str = '\0';
	do {
		uint32_t	m = num;

		num /= base;
		char	c = m - base * num;
		*--str = c < 10 ? c + '0' : c + 'A' - 10;

	} while(num);
	while(*str) {
		*outBuff++ = *str++;
	}
	*outBuff = '\0';
}
