Programmation du NRF51 avec la cl� USB stlink-v2
=================================================

Brancher la cl� et la carte NRF51.
Lancer 2 consoles

Sur la premi�re:
----------------
$ cd /home/nicolas/dev/arm/tools/bin
$ ./run_nrf.sh

Sur la deuxi�me:
----------------
$ telnet 127.0.0.1 4444

halt

nrf51 mass_erase

flash write_image erase <fichier_hex> 0

reset

exit

$

Liste des images (*.hex)

/home/nicolas/dev/workspace_indigo_chibios/ChibiOS-Contrib/demos/NRF51/RT-WVSHARE_BLE400/build/ch.hex
/home/nicolas/dev/workspace_indigo_chibios/NRF51_Test/rtc.hex
