#include "nrf.h"
#include "nrf_gpio.h"
#include "nrf_drv_config.h"
#include "nrf_drv_rtc.h"
#include "nrf_drv_clock.h"

#include "app_error.h"
#include <stdint.h>
#include <stdbool.h>

// use nrf_drv_config.h
/*
add to Makefile
#CFLAGS += -I$(xDK_TOP)/components/drivers_nrf/rtc
#CFLAGS += -I$(xDK_TOP)/components/drivers_nrf/clock
#CFLAGS += -I$(xDK_TOP)/components/libraries/util
#CFLAGS += -I$(xDK_TOP)/components/drivers_nrf/nrf_soc_nosd
#CFLAGS += -I$(xDK_TOP)/components/drivers_nrf/common

#SOURCES += $(xDK_TOP)/components/libraries/util/app_error.c
#SOURCES += $(xDK_TOP)/components/libraries/util/app_util_platform.c
#SOURCES += $(xDK_TOP)/components/libraries/util/nrf_assert.c
#SOURCES += $(xDK_TOP)/components/drivers_nrf/nrf_soc_nosd/nrf_soc.c
#SOURCES += $(xDK_TOP)/components/drivers_nrf/common/nrf_drv_common.c
#SOURCES += $(xDK_TOP)/components/drivers_nrf/hal/nrf_delay.c
#SOURCES += $(xDK_TOP)/components/drivers_nrf/rtc/nrf_drv_rtc.c
#SOURCES += $(xDK_TOP)/components/drivers_nrf/clock/nrf_drv_clock.c


 */

#define COMPARE_COUNTERTIME		(3UL)    /**< Get Compare event COMPARE_TIME seconds after the counter starts from 0. */


#define TICK_EVENT_OUTPUT		17UL	/**< Pin number for indicating tick event. */
#define COMPARE_EVENT_OUTPUT	18UL	/**< Pin number for indicating compare event. */

const nrf_drv_rtc_t rtc = NRF_DRV_RTC_INSTANCE(0); /**< Declaring an instance of nrf_drv_rtc for RTC0. */

/** @brief: Function for handling the RTC0 interrupts.
 * Triggered on TICK and COMPARE0 match.
 */
static void rtc_handler(nrf_drv_rtc_int_type_t int_type)
{
    if (int_type == NRF_DRV_RTC_INT_COMPARE0) {
        nrf_gpio_pin_toggle(COMPARE_EVENT_OUTPUT);
    } else if (int_type == NRF_DRV_RTC_INT_TICK) {
        nrf_gpio_pin_toggle(TICK_EVENT_OUTPUT);
    }
}

/** @brief Function configuring gpio for pin toggling.
 */
static void leds_config(void)
{
    // Configure LED-pins as outputs.
	nrf_gpio_cfg_output(TICK_EVENT_OUTPUT);
	nrf_gpio_cfg_output(COMPARE_EVENT_OUTPUT);
	nrf_gpio_pin_clear(TICK_EVENT_OUTPUT);
	nrf_gpio_pin_clear(COMPARE_EVENT_OUTPUT);
//    LEDS_CONFIGURE(((1<<COMPARE_EVENT_OUTPUT) | (1<<TICK_EVENT_OUTPUT)));
//    LEDS_OFF((1<<COMPARE_EVENT_OUTPUT) | (1<<TICK_EVENT_OUTPUT));
}

/** @brief Function starting the internal LFCLK XTAL oscillator.
 */
static void lfclk_config(void)
{
    ret_code_t err_code = nrf_drv_clock_init(NULL);
    APP_ERROR_CHECK(err_code);

    nrf_drv_clock_lfclk_request();
}

/** @brief Function initialization and configuration of RTC driver instance.
 */
static void rtc_config(void)
{
    uint32_t err_code;

    //Initialize RTC instance
    err_code = nrf_drv_rtc_init(&rtc, NULL, rtc_handler);
    APP_ERROR_CHECK(err_code);

    //Enable tick event & interrupt
    nrf_drv_rtc_tick_enable(&rtc,true);

    //Set compare channel to trigger interrupt after COMPARE_COUNTERTIME seconds
    err_code = nrf_drv_rtc_cc_set(&rtc,0,COMPARE_COUNTERTIME*RTC0_CONFIG_FREQUENCY,true);
    APP_ERROR_CHECK(err_code);

    //Power on RTC instance
    nrf_drv_rtc_enable(&rtc);
}


/**
 * @brief Function for application main entry.
 */
int main(void)
{
    leds_config();

    lfclk_config();

    rtc_config();

    while (true)
    {
        __SEV();
        __WFE();
        __WFE();
    }
}
